import { randomBytes, randomUUID, scryptSync, timingSafeEqual } from 'node:crypto'
import { sql } from './db.ts'

export interface UserRow {
  id: string
  username: string
  email: string | null
  is_guest: boolean
  created_at: string
}

export interface AuthUser {
  id: string
  username: string
  email: string | null
  isGuest: boolean
}

interface UserQueryRow {
  id: string
  username: string
  email: string | null
  is_guest: boolean
}

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const candidate = scryptSync(password, salt, 64)
  const expected = Buffer.from(hash, 'hex')
  return candidate.length === expected.length && timingSafeEqual(candidate, expected)
}

function toAuthUser(row: UserQueryRow): AuthUser {
  return {
    id: row.id,
    username: row.username,
    email: row.email,
    isGuest: row.is_guest,
  }
}

export async function findByToken(token: string): Promise<AuthUser | null> {
  const rows = await sql`
    SELECT u.id, u.username, u.email, u.is_guest
    FROM sessions s
    JOIN users u ON u.id = s.user_id
    WHERE s.token = ${token}
  `
  if (!rows.length) return null
  return toAuthUser(rows[0] as UserQueryRow)
}

export async function createGuestSession(username?: string): Promise<{ user: AuthUser; token: string }> {
  const id = randomUUID()
  const finalName = username?.trim() ? username.trim().slice(0, 24) : `Guest-${randomUUID().slice(0, 4)}`
  const token = randomBytes(32).toString('hex')
  await sql`
    INSERT INTO users (id, username, is_guest)
    VALUES (${id}, ${finalName}, true)
  `
  await sql`INSERT INTO sessions (token, user_id) VALUES (${token}, ${id})`
  return { user: { id, username: finalName, email: null, isGuest: true }, token }
}

export async function register(username: string, email: string, password: string): Promise<{ user: AuthUser; token: string }> {
  const id = randomUUID()
  const token = randomBytes(32).toString('hex')
  const hash = hashPassword(password)
  const cleaned = username.trim().slice(0, 24)
  const lowered = email.trim().toLowerCase()
  try {
    await sql`
      INSERT INTO users (id, username, email, password_hash, is_guest)
      VALUES (${id}, ${cleaned}, ${lowered}, ${hash}, false)
    `
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err)
    if (msg.includes('duplicate') || msg.includes('unique')) {
      const err2 = new Error('Username or email already taken')
      err2.name = 'ConflictError'
      throw err2
    }
    if (msg.includes('invalid input syntax for type')) {
      const err3 = new Error('Invalid email address')
      err3.name = 'BadRequestError'
      throw err3
    }
    throw err
  }
  await sql`INSERT INTO sessions (token, user_id) VALUES (${token}, ${id})`
  return { user: { id, username: cleaned, email: lowered, isGuest: false }, token }
}

export async function login(email: string, password: string): Promise<{ user: AuthUser; token: string } | null> {
  const rows = await sql`
    SELECT id, username, email, password_hash, is_guest
    FROM users
    WHERE lower(email) = ${email.trim().toLowerCase()}
  `
  if (!rows.length) return null
  const row = rows[0] as UserQueryRow & { password_hash: string | null }
  if (!row.password_hash || !verifyPassword(password, row.password_hash)) return null
  const token = randomBytes(32).toString('hex')
  await sql`INSERT INTO sessions (token, user_id) VALUES (${token}, ${row.id})`
  return { user: toAuthUser(row), token }
}

export async function logout(token: string): Promise<void> {
  await sql`DELETE FROM sessions WHERE token = ${token}`
}