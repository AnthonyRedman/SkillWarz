import { sql } from './db.ts'

export interface LeaderboardEntry {
  rank: number
  username: string
  totalKills: number
  totalDeaths: number
  totalScore: number
  bestScore: number
  matchesPlayed: number
  isGuest: boolean
}

export async function getLeaderboard(
  limit = 20,
  includeGuests = false,
): Promise<LeaderboardEntry[]> {
  const rows = await sql`
    SELECT ps.total_kills, ps.total_deaths, ps.total_score, ps.best_score,
           ps.matches_played, u.username, u.is_guest
    FROM player_stats ps
    JOIN users u ON u.id = ps.user_id
    ${includeGuests ? sql`` : sql`WHERE u.is_guest = false`}
    ORDER BY ps.total_score DESC, ps.total_kills DESC
    LIMIT ${limit}
  `
  return (rows as unknown[]).map((row, i) => {
    const r = row as Record<string, unknown>
    return {
      rank: i + 1,
      username: String(r.username),
      totalKills: Number(r.total_kills),
      totalDeaths: Number(r.total_deaths),
      totalScore: Number(r.total_score),
      bestScore: Number(r.best_score),
      matchesPlayed: Number(r.matches_played),
      isGuest: Boolean(r.is_guest),
    }
  })
}

export async function recordMatchResult(
  userId: string,
  kills: number,
  deaths: number,
  score: number,
  durationMs: number,
): Promise<void> {
  await sql`
    INSERT INTO match_history (user_id, kills, deaths, score, duration_ms)
    VALUES (${userId}, ${kills}, ${deaths}, ${score}, ${durationMs})
  `
  await sql`
    INSERT INTO player_stats (user_id, total_kills, total_deaths, total_score, best_kills, best_score, matches_played)
    VALUES (${userId}, ${kills}, ${deaths}, ${score}, ${kills}, ${score}, 1)
    ON CONFLICT (user_id) DO UPDATE SET
      total_kills = player_stats.total_kills + EXCLUDED.total_kills,
      total_deaths = player_stats.total_deaths + EXCLUDED.total_deaths,
      total_score = player_stats.total_score + EXCLUDED.total_score,
      best_kills = GREATEST(player_stats.best_kills, EXCLUDED.best_kills),
      best_score = GREATEST(player_stats.best_score, EXCLUDED.best_score),
      matches_played = player_stats.matches_played + 1,
      updated_at = now()
  `
}

export async function getUserRecord(userId: string): Promise<LeaderboardEntry | null> {
  const rows = await sql`
    SELECT ps.total_kills, ps.total_deaths, ps.total_score, ps.best_score,
           ps.matches_played, u.username, u.is_guest
    FROM player_stats ps
    JOIN users u ON u.id = ps.user_id
    WHERE u.id = ${userId}
  `
  if (!rows.length) return null
  const r = rows[0] as Record<string, unknown>
  return {
    rank: 0,
    username: String(r.username),
    totalKills: Number(r.total_kills),
    totalDeaths: Number(r.total_deaths),
    totalScore: Number(r.total_score),
    bestScore: Number(r.best_score),
    matchesPlayed: Number(r.matches_played),
    isGuest: Boolean(r.is_guest),
  }
}