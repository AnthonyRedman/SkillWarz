import 'dotenv/config'
import cors from 'cors'
import express from 'express'
import * as RAPIER from '@dimforge/rapier3d-compat'
import { defineRoom, listen } from 'colyseus'
import { DeathmatchRoom } from './rooms/DeathmatchRoom.ts'
import { ROOM_NAME } from '../shared/network.ts'
import { ensureSchema, ping } from './db.ts'
import { createGuestSession, findByToken, login, logout, register } from './auth.ts'
import { getLeaderboard, getUserRecord } from './leaderboard.ts'

const port = Number(process.env.PORT ?? 2567)

await RAPIER.init()
await ensureSchema().catch((err) => {
  console.error('[skillwarz] failed to apply schema:', err)
})

listen({
  rooms: {
    [ROOM_NAME]: defineRoom(DeathmatchRoom),
  },
  initializeExpress(app) {
    app.use(cors())
    app.use(express.json())

    app.get('/', (_req, res) => {
      res.json({ game: 'skillwarz', rooms: [ROOM_NAME] })
    })

    app.get('/api/health', async (_req, res) => {
      const dbOk = await ping()
      res.json({ ok: true, db: dbOk })
    })

    app.post('/api/auth/guest', async (_req, res) => {
      try {
        const session = await createGuestSession()
        res.json(session)
      } catch (err) {
        console.error('[skillwarz] guest auth failed:', err)
        res.status(500).json({ error: 'could not create guest account' })
      }
    })

    app.post('/api/auth/register', async (req, res) => {
      const { username, email, password } = (req.body ?? {}) as Record<string, unknown>
      if (typeof username !== 'string' || typeof password !== 'string' || typeof email !== 'string') {
        res.status(400).json({ error: 'username, email, and password are required' })
        return
      }
      try {
        const session = await register(username, email, password)
        res.status(201).json(session)
      } catch (err) {
        const name = err instanceof Error ? err.name : ''
        const status = name === 'ConflictError' ? 409 : 400
        res.status(status).json({ error: err instanceof Error ? err.message : 'registration failed' })
      }
    })

    app.post('/api/auth/login', async (req, res) => {
      const { email, password } = (req.body ?? {}) as Record<string, unknown>
      if (typeof email !== 'string' || typeof password !== 'string') {
        res.status(400).json({ error: 'email and password are required' })
        return
      }
      try {
        const session = await login(email, password)
        if (!session) {
          res.status(401).json({ error: 'invalid credentials' })
          return
        }
        res.json(session)
      } catch (err) {
        console.error('[skillwarz] login failed:', err)
        res.status(500).json({ error: 'login failed' })
      }
    })

    app.post('/api/auth/logout', async (req, res) => {
      const auth = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '')
      if (auth) await logout(auth).catch(() => undefined)
      res.json({ ok: true })
    })

    app.get('/api/auth/me', async (req, res) => {
      const auth = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '')
      const user = auth ? await findByToken(auth) : null
      if (!user) {
        res.status(401).json({ error: 'unauthorized' })
        return
      }
      const record = await getUserRecord(user.id)
      res.json({ user, record })
    })

    app.get('/api/leaderboard', async (req, res) => {
      const raw = (req.query as Record<string, unknown>).limit
      const limit = Math.min(100, Math.max(1, Number(raw) || 20))
      const includeGuests = (req.query as Record<string, unknown>).guests === '1'
      try {
        const board = await getLeaderboard(limit, includeGuests)
        res.json({ players: board })
      } catch (err) {
        console.error('[skillwarz] leaderboard failed:', err)
        res.status(500).json({ error: 'leaderboard unavailable' })
      }
    })
  },
}, port)
  .then((server) => {
    server.onShutdown(() => {
      return process.exit(0)
    })
    console.log(`Skillwarz server listening on http://localhost:${port}`)
    console.log(`Room "${ROOM_NAME}" at ws://localhost:${port}`)
  })
  .catch((err) => {
    console.error('Failed to boot Skillwarz server:', err)
    process.exit(1)
  })