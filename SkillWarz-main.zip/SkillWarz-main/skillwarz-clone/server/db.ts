import { neon } from '@neondatabase/serverless'
import { readFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const DATABASE_URL = process.env.DATABASE_URL

export const sql = neon(DATABASE_URL ?? '')

export async function ensureSchema(): Promise<void> {
  const here = dirname(fileURLToPath(import.meta.url))
  const ddl = await readFile(join(here, 'schema.sql'), 'utf8')
  const statements = ddl
    .split(';')
    .map((s) => s.trim())
    .filter((s) => s.length > 0)
  for (const statement of statements) {
    await sql.query(statement)
  }
}

export async function ping(): Promise<boolean> {
  try {
    await sql`SELECT 1`
    return true
  } catch {
    return false
  }
}