import { Room, type Client } from 'colyseus'
import * as RAPIER from '@dimforge/rapier3d-compat'
import {
  DIFFICULTY,
  MOVEMENT,
  WORLD,
  type Difficulty,
} from '../../shared/constants.ts'
import {
  addArenaColliders,
  ARENA_STATIC_BOXES,
  BOUNCE_PADS,
  TELEPORTERS,
  type TriggerDef,
} from '../../shared/map.ts'
import {
  MAX_PLAYERS,
  type JoinOptions,
  type PlayerInputMessage,
  type ShootMessage,
} from '../../shared/network.ts'
import { DeathmatchState, PlayerState } from '../../shared/networkSchema.ts'
import {
  createMotionState,
  createPlayerBody,
  PLAYER_HALF_HEIGHT,
  PLAYER_RADIUS,
  stepPlayerMotion,
  type PlayerMotionState,
} from '../../shared/playerSim.ts'
import { FIXED_TIMESTEP } from '../../shared/timestep.ts'
import { BOT_SPAWNS, HUMAN_SPAWNS, pickSpawn } from '../../shared/spawn.ts'
import { resolveBotShot, resolveShot } from '../../shared/combat.ts'
import { createBotBrain, BOT_EYE, type BotBrain } from '../../shared/botAI.ts'
import { stepBot } from '../../shared/botSim.ts'
import { WEAPONS, BOT_WEAPON, type WeaponName } from '../../shared/weapons.ts'
import { findByToken } from '../auth.ts'
import { recordMatchResult } from '../leaderboard.ts'

const HUMAN_MAX_HEALTH = 100
const TRIGGER_COOLDOWN_MS = 1200
const INPUT_TIMEOUT_MS = 350
const LIMBO = { x: 0, y: 100, z: 0 }
const BOT_COUNT_BY_DIFFICULTY: Record<Difficulty, number> = {
  easy: 3,
  normal: 4,
  hard: 5,
}

function overlapsPlayer(
  trigger: TriggerDef,
  player: { x: number; y: number; z: number },
): boolean {
  return (
    Math.abs(trigger.center[0] - player.x) < trigger.half[0] + PLAYER_RADIUS &&
    Math.abs(trigger.center[1] - player.y) < trigger.half[1] + PLAYER_HALF_HEIGHT &&
    Math.abs(trigger.center[2] - player.z) < trigger.half[2] + PLAYER_RADIUS
  )
}

export class DeathmatchRoom extends Room<{ state: DeathmatchState }> {
  private world!: RAPIER.World
  private bodies = new Map<string, RAPIER.RigidBody>()
  private motions = new Map<string, PlayerMotionState>()
  private brains = new Map<string, BotBrain>()
  private isBot = new Set<string>()
  private inputs = new Map<string, PlayerInputMessage>()
  private lastInputAt = new Map<string, number>()
  private lastShootAt = new Map<string, number>()
  private deadUntil = new Map<string, number>()
  private bounceLast = new Map<string, number>()
  private teleportLast = new Map<string, number>()
  private difficulty: Difficulty = 'normal'
  private botsCreated = false
  private userIds = new Map<string, string>()
  private joinedAt = new Map<string, number>()

  onCreate() {
    this.maxClients = MAX_PLAYERS
    this.world = new RAPIER.World({ x: 0, y: WORLD.gravity, z: 0 })
    this.world.timestep = FIXED_TIMESTEP
    addArenaColliders(this.world, RAPIER, ARENA_STATIC_BOXES)
    this.setState(new DeathmatchState())

    this.onMessage('input', (client, message: PlayerInputMessage) => {
      this.inputs.set(client.sessionId, message)
      this.lastInputAt.set(client.sessionId, Date.now())
      const player = this.state.players.get(client.sessionId)
      if (player) player.yaw = message.yaw
    })

    this.onMessage('shoot', (client, message: ShootMessage) => {
      this.handleShoot(client.sessionId, message)
    })

    this.setSimulationInterval(() => this.simulate(), 1000 / 60)
  }

  onJoin(client: Client, options?: JoinOptions) {
    const difficulty: Difficulty =
      options?.difficulty === 'easy' || options?.difficulty === 'hard'
        ? options.difficulty
        : 'normal'
    if (!this.botsCreated || !this.difficulty) {
      this.difficulty = difficulty
    }
    if (!this.botsCreated) {
      this.spawnBots()
      this.botsCreated = true
    }
    let name = options?.name?.trim() || `Host-${client.sessionId.slice(0, 5)}`
    if (options?.authToken) {
      void findByToken(options.authToken)
        .then((user) => {
          if (user && this.state.players.has(client.sessionId)) {
            this.userIds.set(client.sessionId, user.id)
            const player = this.state.players.get(client.sessionId)
            if (player) {
              player.name = user.username
              this.state.players.set(client.sessionId, player)
            }
          }
        })
        .catch(() => undefined)
    }
    this.joinedAt.set(client.sessionId, Date.now())
    const spawn = pickSpawn(
      HUMAN_SPAWNS,
      this.occupants(),
    )
    this.createEntity(client.sessionId, name, spawn, false, HUMAN_MAX_HEALTH)
  }

  onLeave(client: Client) {
    const id = client.sessionId
    void this.persistMatch(id)
    const body = this.bodies.get(id)
    if (body) this.world.removeRigidBody(body)
    this.bodies.delete(id)
    this.motions.delete(id)
    this.inputs.delete(id)
    this.lastInputAt.delete(id)
    this.lastShootAt.delete(id)
    this.deadUntil.delete(id)
    this.userIds.delete(id)
    this.joinedAt.delete(id)
    this.state.players.delete(id)
  }

  private async persistMatch(id: string): Promise<void> {
    const userId = this.userIds.get(id)
    const player = this.state.players.get(id)
    if (!userId || !player) return
    const started = this.joinedAt.get(id) ?? Date.now()
    try {
      await recordMatchResult(
        userId,
        player.kills,
        player.deaths,
        player.score,
        Date.now() - started,
      )
    } catch (err) {
      console.error('[skillwarz] failed to persist match for', userId, err)
    }
  }

  private spawnBots() {
    const count = BOT_COUNT_BY_DIFFICULTY[this.difficulty]
    for (let i = 0; i < count; i++) {
      const spawn = pickSpawn(BOT_SPAWNS, this.occupants())
      const brain = createBotBrain(i)
      this.brains.set(`bot-${i}`, brain)
      this.createEntity(
        `bot-${i}`,
        `Bot ${i + 1}`,
        spawn,
        true,
        DIFFICULTY[this.difficulty].botHealth,
      )
    }
  }

  private createEntity(
    id: string,
    name: string,
    spawn: readonly [number, number, number],
    bot: boolean,
    maxHealth: number,
  ) {
    this.bodies.set(id, createPlayerBody(this.world, RAPIER, spawn, id))
    this.motions.set(id, createMotionState())
    if (bot) this.isBot.add(id)
    this.deadUntil.delete(id)
    this.state.players.set(
      id,
      new PlayerState({
        name,
        x: spawn[0],
        y: spawn[1],
        z: spawn[2],
        yaw: 0,
        health: maxHealth,
        maxHealth,
        score: 0,
        kills: 0,
        deaths: 0,
        isBot: bot,
      }),
    )
  }

  private occupants(): { x: number; z: number }[] {
    const list: { x: number; z: number }[] = []
    this.bodies.forEach((body, id) => {
      if (this.deadUntil.has(id)) return
      const p = body.translation()
      list.push({ x: p.x, z: p.z })
    })
    return list
  }

  private handleShoot(id: string, message: ShootMessage) {
    if (this.isBot.has(id)) return
    if (this.deadUntil.has(id)) return
    const body = this.bodies.get(id)
    if (!body) return
    const def = WEAPONS[message.weapon]
    if (!def) return

    const now = Date.now()
    const minGap = Math.round((1 / def.fireRate) * 1000)
    if (now - (this.lastShootAt.get(id) ?? 0) < minGap) return
    this.lastShootAt.set(id, now)

    const len = Math.hypot(message.dx, message.dy, message.dz)
    if (!(len > 1e-6)) return
    const dir = {
      x: message.dx / len,
      y: message.dy / len,
      z: message.dz / len,
    }
    const result = resolveShot(
      this.world,
      RAPIER,
      message.weapon,
      { x: message.ox, y: message.oy, z: message.oz },
      dir,
      body,
    )
    if (result) this.damage(result.victimId, result.damage, id, message.weapon)
  }

  private damage(
    victimId: string,
    amount: number,
    killerId: string,
    weapon: WeaponName | 'bot',
  ) {
    const victim = this.state.players.get(victimId)
    if (!victim) return
    if (victim.health <= 0 || this.deadUntil.has(victimId)) return
    victim.health = Math.max(0, Math.round(victim.health - amount))
    if (victim.health <= 0) this.kill(killerId, victimId, weapon)
  }

  private kill(
    killerId: string,
    victimId: string,
    weapon: WeaponName | 'bot',
  ) {
    const killer = this.state.players.get(killerId)
    const victim = this.state.players.get(victimId)
    if (!victim) return

    victim.health = 0
    victim.deaths = Math.min(255, victim.deaths + 1)

    if (killer && !this.isBot.has(killerId) && killerId !== victimId) {
      killer.kills = Math.min(255, killer.kills + 1)
      const pts = Math.round(100 * DIFFICULTY[this.difficulty].scoreMultiplier)
      killer.score = Math.min(65535, killer.score + pts)
    }

    this.broadcast('killfeed', {
      killer: killer?.name ?? '?',
      victim: victim.name,
      killerIsBot: killer ? this.isBot.has(killerId) : false,
      victimIsBot: this.isBot.has(victimId),
      weapon,
    })

    const respawnMs = this.isBot.has(victimId)
      ? DIFFICULTY[this.difficulty].respawnTime
      : DIFFICULTY[this.difficulty].respawnTime
    this.deadUntil.set(victimId, Date.now() + Math.round(respawnMs * 1000))

    const body = this.bodies.get(victimId)
    if (body) {
      body.setTranslation(LIMBO, true)
      body.setLinvel({ x: 0, y: 0, z: 0 }, true)
      body.setAngvel({ x: 0, y: 0, z: 0 }, true)
    }
  }

  private respawn(id: string) {
    const bot = this.isBot.has(id)
    const spawn = pickSpawn(bot ? BOT_SPAWNS : HUMAN_SPAWNS, this.occupants())
    const body = this.bodies.get(id)
    if (body) {
      body.setTranslation({ x: spawn[0], y: spawn[1], z: spawn[2] }, true)
      body.setLinvel({ x: 0, y: 0, z: 0 }, true)
      body.setAngvel({ x: 0, y: 0, z: 0 }, true)
    }
    this.deadUntil.delete(id)
    const player = this.state.players.get(id)
    if (player) {
      player.health = player.maxHealth
      player.yaw = 0
    }
    if (bot) {
      const brain = this.brains.get(id)
      if (brain) {
        brain.wasDead = true
        brain.state = 'patrol'
      }
    }
  }

  private simulate() {
    const now = Date.now()
    for (const [id, until] of [...this.deadUntil]) {
      if (now >= until) this.respawn(id)
    }

    this.bodies.forEach((body, id) => {
      if (this.isBot.has(id)) return
      if (this.deadUntil.has(id)) {
        body.setTranslation(LIMBO, true)
        body.setLinvel({ x: 0, y: 0, z: 0 }, true)
        return
      }
      const input = this.inputs.get(id)
      const lastAt = this.lastInputAt.get(id) ?? 0
      const fresh = input !== undefined && now - lastAt < INPUT_TIMEOUT_MS
      if (!input) return
      const motion = this.motions.get(id)
      if (!motion) return
      const effective = fresh
        ? input
        : {
            ...input,
            forward: false,
            backward: false,
            left: false,
            right: false,
            jump: false,
            sprint: false,
            crouch: false,
          }
      stepPlayerMotion(this.world, RAPIER, body, motion, effective, FIXED_TIMESTEP)
      this.applyTriggers(id, body, now)
    })

    this.stepBots()
    this.world.step()

    this.bodies.forEach((body, id) => {
      const player = this.state.players.get(id)
      if (!player) return
      const pos = body.translation()
      player.x = pos.x
      player.y = pos.y
      player.z = pos.z
    })
  }

  private pickHumanTarget(botId: string): {
    id: string
    x: number
    y: number
    z: number
    body: RAPIER.RigidBody
  } | null {
    const start = this.bodies.get(botId)?.translation()
    let best: {
      id: string
      x: number
      y: number
      z: number
      body: RAPIER.RigidBody
    } | null = null
    let bestDist = Infinity
    this.bodies.forEach((body, id) => {
      if (this.isBot.has(id)) return
      if (this.deadUntil.has(id)) return
      const p = body.translation()
      const d = start
        ? Math.hypot(p.x - start.x, p.z - start.z)
        : Infinity
      if (d < bestDist) {
        bestDist = d
        best = { id, x: p.x, y: p.y, z: p.z, body }
      }
    })
    return best
  }

  private stepBots() {
    this.brains.forEach((brain, id) => {
      const body = this.bodies.get(id)
      if (!body) return

      if (this.deadUntil.has(id)) {
        body.setTranslation(LIMBO, true)
        body.setLinvel({ x: 0, y: 0, z: 0 }, true)
        return
      }

      const target = this.pickHumanTarget(id)
      const result = stepBot(
        this.world,
        RAPIER,
        brain,
        body,
        target ? { x: target.x, y: target.y, z: target.z } : null,
        target?.body ?? null,
        this.difficulty,
        FIXED_TIMESTEP,
      )
      body.setLinvel({ x: result.vx, y: result.vy, z: result.vz }, true)

      const pos = body.translation()
      const player = this.state.players.get(id)

      if (target) {
        const tx = target.x - pos.x
        const tz = target.z - pos.z
        const dist = Math.hypot(tx, tz)
        if (player && dist > 0.01) {
          const yaw = Math.atan2(-tx / dist, -tz / dist)
          player.yaw = yaw
        }
        if (result.wantShoot) {
          this.botFire(id, pos, target)
        }
      }
    })
  }

  private botFire(
    id: string,
    pos: RAPIER.Vector,
    target: NonNullable<ReturnType<DeathmatchRoom['pickHumanTarget']>>,
  ) {
    const cfg = DIFFICULTY[this.difficulty]
    const damage = Math.max(1, Math.round(BOT_WEAPON.damage * cfg.botDamage))
    const body = this.bodies.get(id)
    if (!body) return
    const eye = { x: pos.x, y: pos.y + BOT_EYE, z: pos.z }
    const aim = {
      x: target.x - eye.x,
      y: target.y + 0.2 - eye.y,
      z: target.z - eye.z,
    }
    const len = Math.hypot(aim.x, aim.y, aim.z)
    if (len < 0.001) return
    let dx = aim.x / len
    let dy = aim.y / len
    let dz = aim.z / len
    const spread = BOT_WEAPON.spread
    dx += (Math.random() - 0.5) * spread
    dy += (Math.random() - 0.5) * spread
    dz += (Math.random() - 0.5) * spread
    const dl = Math.hypot(dx, dy, dz)
    dx /= dl
    dy /= dl
    dz /= dl
    const result = resolveBotShot(
      this.world,
      RAPIER,
      eye,
      { x: dx, y: dy, z: dz },
      body,
      damage,
    )
    if (result) this.damage(result.victimId, result.damage, id, 'bot')
  }

  private applyTriggers(sessionId: string, body: RAPIER.RigidBody, now: number) {
    const pos = body.translation()
    for (let i = 0; i < BOUNCE_PADS.length; i++) {
      const pad = BOUNCE_PADS[i]
      if (!overlapsPlayer(pad, { x: pos.x, y: pos.y, z: pos.z })) continue
      const key = `${sessionId}:b${i}`
      const last = this.bounceLast.get(key) ?? 0
      if (now - last < TRIGGER_COOLDOWN_MS) continue
      this.bounceLast.set(key, now)
      const vel = body.linvel()
      body.setLinvel({ x: vel.x, y: MOVEMENT.bouncePadVelocity, z: vel.z }, true)
    }
    for (let i = 0; i < TELEPORTERS.length; i++) {
      const teleporter = TELEPORTERS[i]
      if (!overlapsPlayer(teleporter, { x: pos.x, y: pos.y, z: pos.z })) continue
      const key = `${sessionId}:t${i}`
      const last = this.teleportLast.get(key) ?? 0
      if (now - last < TRIGGER_COOLDOWN_MS) continue
      this.teleportLast.set(key, now)
      const vel = body.linvel()
      body.setTranslation(
        { x: teleporter.exit[0], y: teleporter.exit[1], z: teleporter.exit[2] },
        true,
      )
      body.setLinvel({ x: vel.x, y: 0, z: vel.z }, true)
    }
  }
}