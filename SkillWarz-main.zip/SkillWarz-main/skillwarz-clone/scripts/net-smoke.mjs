import { Client } from '@colyseus/sdk'

const WS_URL = process.env.WS_URL ?? 'ws://localhost:2567'
const ROOM_NAME = 'deathmatch'

function snapshot(room) {
  const out = {}
  room.state.players.forEach((p, key) => {
    out[key] = {
      name: p.name,
      x: p.x,
      y: p.y,
      z: p.z,
      yaw: p.yaw,
      health: p.health,
      maxHealth: p.maxHealth,
      score: p.score,
      kills: p.kills,
      deaths: p.deaths,
      isBot: p.isBot,
    }
  })
  return out
}

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

async function latest(room) {
  return new Promise((resolve) => {
    const poll = () => {
      const s = snapshot(room)
      if (Object.keys(s).length >= 2) resolve(s)
      else setTimeout(poll, 50)
    }
    poll()
  })
}

function baseInput() {
  return { yaw: 0, forward: false, backward: false, left: false, right: false, jump: false, sprint: false, crouch: false }
}

const failures = []
let passCount = 0

function check(name, cond, detail = '') {
  if (cond) {
    passCount++
    console.log(`ok  - ${name}`)
  } else {
    failures.push(name)
    console.log(`FAIL - ${name} ${detail}`)
  }
}

function aimAt(from, to) {
  const f = { x: from.x, y: from.y + 0.8, z: from.z }
  const t = { x: to.x, y: to.y, z: to.z }
  const len = Math.hypot(t.x - f.x, t.y - f.y, t.z - f.z)
  if (len < 1e-6) return { from: f, dir: { x: 0, y: 0, z: -1 } }
  return {
    from: f,
    dir: { x: (t.x - f.x) / len, y: (t.y - f.y) / len, z: (t.z - f.z) / len },
  }
}

function shootAt(room, from, to) {
  const aim = aimAt(from, to)
  room.send('shoot', {
    weapon: 'pistol',
    ox: aim.from.x, oy: aim.from.y, oz: aim.from.z,
    dx: aim.dir.x, dy: aim.dir.y, dz: aim.dir.z,
  })
}

function aliveIn(room) {
  const s = snapshot(room)
  return Object.values(s).filter((p) => p.health > 0 && p.y < 50)
}

async function waitAlive(room) {
  for (let i = 0; i < 100; i++) {
    const alive = aliveIn(room)
    if (alive.length > 0) return snapshot(room)
    await wait(100)
  }
  return snapshot(room)
}

const client1 = new Client(WS_URL)
const client2 = new Client(WS_URL)

const killfeed = []
const room1 = await client1.joinOrCreate(ROOM_NAME, { name: 'Alpha', difficulty: 'easy' })
const room2 = await client2.joinOrCreate(ROOM_NAME, { name: 'Bravo' })
room1.onMessage('killfeed', (message) => killfeed.push(message))

await wait(400)
let s = await latest(room1)
const aId = room1.sessionId
const bId = room2.sessionId

const startA = s[aId]
const startB = s[bId]
check('both human players present', Object.keys(s).length >= 2, JSON.stringify(Object.keys(s)))
check('no spawn overlap in x/z', Math.hypot(startA.x - startB.x, startA.z - startB.z) > 5)

const bots = Object.values(s).filter((p) => p.isBot)
check('server spawned bots', bots.length > 0, `bots=${bots.length}`)
check('bots spawn at full health', bots.every((b) => b.health === b.maxHealth))

console.log('  COMBAT: human kills a bot (resolveShot + killfeed + score + death + respawn)')
{
  let alphaKilledBot = false
  let victimBotName = ''
  let killsA0 = snapshot(room1)[aId]?.kills ?? 0
  let scoreA0 = snapshot(room1)[aId]?.score ?? 0

  for (let attempt = 0; attempt < 5 && !alphaKilledBot; attempt++) {
    await waitAlive(room1)
    await wait(200)
    const snapNow = snapshot(room1)
    const selfNow = snapNow[aId]
    if (!selfNow || selfNow.health <= 0) { await wait(500); continue }
    killsA0 = selfNow.kills
    scoreA0 = selfNow.score

    for (let i = 0; i < 40 && !alphaKilledBot; i++) {
      const snap = snapshot(room1)
      const selfShot = snap[aId]
      const botsA = Object.entries(snap).filter(([, p]) => p.isBot && p.health > 0)
      if (!selfShot || selfShot.health <= 0 || botsA.length === 0) { await wait(80); continue }
      const kill = killfeed.find((e) => e.killer === 'Alpha' && e.victim.startsWith('Bot'))
      if (kill) { alphaKilledBot = true; victimBotName = kill.victim; break }
      const aggro = killfeed
        .filter((e) => e.victim === 'Alpha' && e.killerIsBot)
        .at(-1)?.killer
      let botEntry = botsA.find(([, p]) => p.name === aggro)
      if (!botEntry) {
        let best = null
        let bestD = Infinity
        for (const [k, p] of botsA) {
          const d = Math.hypot(p.x - selfShot.x, p.z - selfShot.z)
          if (d < bestD) { bestD = d; best = [k, p] }
        }
        botEntry = best
      }
      shootAt(room1, selfShot, botEntry[1])
      await wait(80)
    }
    if (!alphaKilledBot) { await wait(2000) }
  }

  check('human kills a bot (killfeed confirmed)', alphaKilledBot,
    JSON.stringify(killfeed.slice(-5)))

  const afterSnap = snapshot(room1)
  check('killer kill-count incremented', afterSnap[aId]?.kills > killsA0,
    `kills ${killsA0} -> ${afterSnap[aId]?.kills}`)
  check('killer scored > 0', afterSnap[aId]?.score > scoreA0,
    `score ${scoreA0} -> ${afterSnap[aId]?.score}`)

  const victimBot = Object.values(afterSnap).find((p) => p.isBot && p.name === victimBotName)
  check('bot victim death-count incremented', !!victimBot && victimBot.deaths >= 1,
    `deaths=${victimBot?.deaths}`)

  const botRespawned = await new Promise((resolve) => {
    const start = Date.now()
    const tick = () => {
      const cur = snapshot(room1)
      const bot = Object.values(cur).find((p) => p.isBot && p.name === victimBotName)
      if (bot && bot.health >= bot.maxHealth && bot.y < 50) resolve(true)
      else if (Date.now() - start > 15000) resolve(false)
      else setTimeout(tick, 200)
    }
    tick()
  })
  check('bot respawns at full health', botRespawned)
}

console.log('  MOVEMENT: server-authoritative position + input timeout')
{
  const waitForPlayer = async (room, id) => {
    for (let i = 0; i < 100; i++) {
      const s = snapshot(room)
      if (s[id] && s[id].health > 0 && s[id].y < 50) return s
      await wait(100)
    }
    return snapshot(room)
  }
  const walk = async () => {
    let attempt = 0
    while (attempt < 4) {
      attempt++
      await waitForPlayer(room1, bId)
      const s0 = snapshot(room1)
      const bNow = s0[bId]
      if (!bNow) { await wait(200); continue }
      const startZ = bNow.z
      let w = baseInput()
      w.forward = true
      for (let i = 0; i < 90; i++) {
        room2.send('input', { ...w })
        await wait(16)
      }
      w.forward = false
      await wait(350)
      const s1 = snapshot(room1)
      const moved = s1[bId]
      if (!moved || moved.health <= 0) { await wait(200); continue }
      const walked = Math.abs(moved.z - startZ)
      if (walked > 2) {
        check('server-authoritative: Bravo actually moved', true, `dZ=${walked.toFixed(2)}`)
        check('Bravo advanced toward -Z', moved.z < startZ)
        return { s1, moved, startZ }
      }
      check('server-authoritative: Bravo actually moved', false, `dZ=${walked.toFixed(2)}`)
      return null
    }
    check('server-authoritative: Bravo actually moved', false, 'Bravo never stayed alive for a walk')
    return null
  }
  const res = await walk()
  if (res) {
    const { s1, moved } = res
    const s2 = snapshot(room2)
    check('position authority consistent',
      Math.abs(s1[bId].x - s2[bId].x) < 1e-6 && Math.abs(s1[bId].z - s2[bId].z) < 1e-6,
      JSON.stringify({ r1: s1[bId], r2: s2[bId] }))

    let yawMsg = baseInput()
    yawMsg.yaw = Math.PI / 2
    yawMsg.forward = true
    for (let i = 0; i < 60; i++) {
      room2.send('input', { ...yawMsg })
      await wait(16)
    }
    yawMsg.forward = false
    await wait(200)
    const s3 = snapshot(room1)
    const turned = s3[bId]
    check('yaw changes steering on server', Math.abs(turned.x - moved.x) > 1,
      `x ${moved.x.toFixed(1)} -> ${turned.x.toFixed(1)}`)

    const before = snapshot(room1)[bId]
    await wait(500)
    const after = snapshot(room1)[bId]
    check('idle player stays put', Math.hypot(after.x - before.x, after.z - before.z) < 2,
      `dxz=${Math.hypot(after.x - before.x, after.z - before.z).toFixed(3)}`)
  }
}

await room1.leave()
await room2.leave()

if (failures.length) {
  console.error(`\n${failures.length} failure(s): ${failures.join(', ')}`)
  process.exit(1)
}
console.log(`\nall ${passCount} checks passed`)
process.exit(0)