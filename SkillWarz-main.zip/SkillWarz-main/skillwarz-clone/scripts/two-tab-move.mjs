import { chromium } from 'playwright-core'

const BROWSER =
  process.env.CHROME_PATH ??
  '/Users/devansh/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell'
const APP_URL = process.env.APP_URL ?? 'http://localhost:5173'
const WALK_MS = 1100

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

async function startGame(page) {
  await page.waitForSelector('.menu-card', { timeout: 30000 })
  await page.click('.difficulty-card:has-text("Easy")')
  await page.click('.menu-btn:has-text("CLICK TO PLAY")')
}

async function netState(page) {
  return page.evaluate(() => {
    const s = window.__skillwarzNet.getState()
    return {
      status: s.status,
      selfId: s.selfId,
      players: Object.fromEntries(
        Object.entries(s.players).map(([id, p]) => [
          id,
          { name: p.name, x: p.x, y: p.y, z: p.z },
        ]),
      ),
    }
  })
}

async function waitOnline2(page) {
  for (let i = 0; i < 120; i++) {
    const s = await netState(page)
    if (s.status === 'online' && Object.keys(s.players).length === 2) return s
    await wait(250)
  }
  throw new Error('never reached ONLINE with 2 players')
}

const browser = await chromium.launch({
  executablePath: BROWSER,
  headless: true,
  args: ['--use-gl=swiftshader'],
})
const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } })

const pageA = await ctx.newPage()
const pageB = await ctx.newPage()
for (const p of [pageA, pageB]) {
  await p.goto(APP_URL)
  await startGame(p)
}

const sa = await waitOnline2(pageA)
const sb = await waitOnline2(pageB)
const aId = sa.selfId
const bId = sb.selfId
console.log('tabA ONLINE·2  self=', aId.slice(0, 5), 'remote=', sa.players[bId]?.name)
console.log('tabB ONLINE·2  self=', bId.slice(0, 5), 'remote=', sb.players[aId]?.name)

const bStart = sa.players[bId]
const relA = sb.players[aId]

await pageA.keyboard.down('KeyW')
await wait(WALK_MS)
await pageA.keyboard.up('KeyW')
await wait(600)

const sa2 = await netState(pageA)
const sb2 = await netState(pageB)
const bAfter = sa2.players[bId]
const relA2 = sb2.players[aId]

const dz = (bAfter.z - bStart.z).toFixed(2)
console.log(`tabB remote(A) moved: z ${relA.z.toFixed(2)} -> ${relA2.z.toFixed(2)} (server dz=${dz})`)

const results = []
results.push(['tabA still ONLINE with both players', Object.keys(sa2.players).length === 2])
results.push(['tabB still ONLINE with both players', Object.keys(sb2.players).length === 2])
results.push(['remote A really moved (z decreased)', relA2.z < relA.z - 1.5, `dZ=${relA.z - relA2.z}`])
results.push([
  'predicted == confirmed (tabA equals tabB view)',
  Math.abs(sa2.players[aId].x - relA2.x) < 0.5 && Math.abs(sa2.players[aId].z - relA2.z) < 0.5,
  `A ${sa2.players[aId].x.toFixed(2)},${sa2.players[aId].z.toFixed(2)} vs B view ${relA2.x.toFixed(2)},${relA2.z.toFixed(2)}`,
])

let failed = 0
for (const [name, ok, detail = ''] of results) {
  if (ok) console.log(`ok  - ${name}`)
  else {
    failed++
    console.log(`FAIL - ${name} ${detail}`)
  }
}

await browser.close()
process.exit(failed ? 1 : 0)