import { chromium } from 'playwright-core'

const BROWSER =
  process.env.CHROME_PATH ??
  '/Users/devansh/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-arm64/chrome-headless-shell'
const APP_URL = process.env.APP_URL ?? 'http://localhost:5173'

function wait(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

async function startGame(page) {
  await page.waitForSelector('.menu-card', { timeout: 30000 })
  await page.click('.difficulty-card:has-text("Easy")')
  await page.click('.menu-btn:has-text("CLICK TO PLAY")')
}

async function netHooks(page) {
  return page.evaluate(() => {
    const net = window.__skillwarzNet?.getState?.()
    const game = window.__skillwarzGame?.getState?.()
    return {
      status: net?.status ?? 'idle',
      selfId: net?.selfId ?? null,
      players: Object.fromEntries(
        Object.entries(net?.players ?? {}).map(([id, p]) => [
          id,
          { name: p.name, x: p.x, y: p.y, z: p.z, health: p.health, kills: p.kills, deaths: p.deaths, isBot: p.isBot },
        ]),
      ),
      killFeed: game?.killFeed ?? [],
    }
  })
}

async function waitFor(fn, timeoutMs = 25000, interval = 250) {
  const start = Date.now()
  for (;;) {
    const v = await fn()
    if (v) return v
    if (Date.now() - start > timeoutMs) return null
    await wait(interval)
  }
}

const humansOK = (h) =>
  h.status === 'online' &&
  Object.values(h.players).filter((p) => !p.isBot).length >= 2 &&
  Object.values(h.players).filter((p) => p.isBot).length > 0

async function waitOnline(pageVar) {
  const h = await waitFor(async () => {
    const s = await netHooks(pageVar)
    return humansOK(s) ? s : null
  })
  if (!h) throw new Error('never reached ONLINE with 2 humans + bots')
  return h
}

async function fireBurst(pageVar, selfIdInner) {
  await pageVar.evaluate(([sid]) => {
    window.__burstRunning = true
    const loop = async () => {
      const net = window.__skillwarzNet.getState()
      const self = net.players[sid]
      if (!self || !window.__burstRunning) return
      const alive = self.health > 0
      const bots = Object.values(net.players).filter((p) => p.isBot && p.health > 0)
      let host = null
      for (const [_id, p] of Object.entries(net.players)) {
        if (p.isBot && p.y < 50 && (Math.hypot(p.x - self.x, p.z - self.z) < (host ? Math.hypot(host.x - self.x, host.z - self.z) : 1e9)))
          host = { ...p }
      }
      const aggro = bots[0] ?? Object.values(net.players).find((p) => p.isBot)
      let target = host ?? aggro
      if (!self || !target || !alive) { setTimeout(loop, 90); return }
      const dx = target.x - self.x
      const dy = target.y - self.y
      const dz = target.z - self.z
      const len = Math.hypot(dx, dy, dz) || 1
      window.__skillwarzSend.shoot({
        weapon: 'pistol',
        ox: self.x, oy: self.y + 0.8, oz: self.z,
        dx: dx / len, dy: dy / len, dz: dz / len,
      })
      setTimeout(loop, 100)
    }
    loop()
  }, [selfIdInner])
}

const browser = await chromium.launch({
  executablePath: BROWSER,
  headless: true,
  args: ['--use-gl=swiftshader'],
})
const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } })

const pageA = await ctx.newPage()
const pageB = await ctx.newPage()
await pageA.goto(APP_URL)
await startGame(pageA)
await pageB.goto(APP_URL)
await startGame(pageB)

const hA0 = await waitOnline(pageA)
const hB0 = await waitOnline(pageB)
const aId = hA0.selfId
const bId = hB0.selfId
console.log('tabA ONLINE self=', aId.slice(0, 5), 'humans=', Object.values(hA0.players).filter((p) => !p.isBot).length,
  'bots=', Object.values(hA0.players).filter((p) => p.isBot).length)
console.log('tabB ONLINE self=', bId.slice(0, 5), 'humans=', Object.values(hB0.players).filter((p) => !p.isBot).length,
  'bots=', Object.values(hB0.players).filter((p) => p.isBot).length)

const results = []
results.push(['tabA sees remote human', !!hA0.players[bId]])
results.push(['tabB sees remote human', !!hB0.players[aId]])
results.push(['server spawned bots (tabA)', Object.values(hA0.players).filter((p) => p.isBot).length > 0])
results.push(['bots visible to both tabs', Object.values(hB0.players).filter((p) => p.isBot).length > 0])

await fireBurst(pageA, aId)

const killRes = await waitFor(async () => {
  const h = await netHooks(pageA)
  return h.killFeed.length > 0 ? h : null
}, 25000)
results.push(['killfeed populated in tabA UI', !!killRes,
  killRes ? killRes.killFeed.slice(-3).map((k) => k.text).join(' | ') : ''])
results.push(['killfeed contains a kill line', !!killRes && killRes.killFeed.some((k) => /killed/.test(k.text)),
  killRes?.killFeed.slice(-3).map((k) => k.text).join(' | ') ?? ''])

const killCause = await waitFor(async () => {
  const h = await netHooks(pageA)
  const hb = await netHooks(pageB)
  const aNow = hb.players[aId] ?? h.players[aId]
  return aNow && aNow.kills > 0 ? { aNow } : null
}, 30000)
results.push(['killer (tabA) has kills > 0 on server', !!killCause,
  killCause ? `kills=${killCause.aNow.kills}` : 'still 0'])

const botDeath = await waitFor(async () => {
  const h = await netHooks(pageA)
  const deadBot = Object.values(h.players).find((p) => p.isBot && p.deaths > 0)
  return deadBot ? { deadBot } : null
}, 30000)
results.push(['a bot has deaths > 0 on server (tabA view)', !!botDeath,
  botDeath ? `deaths=${botDeath.deadBot.deaths}` : 'no bot death seen'])

await pageA.evaluate(() => { window.__burstRunning = false })
await wait(600)
const hA3 = await netHooks(pageA)
results.push(['tabA still ONLINE at end', hA3.status === 'online'])

let failed = 0
for (const [name, ok, detail = ''] of results) {
  if (ok) console.log(`ok  - ${name}`)
  else {
    failed++
    console.log(`FAIL - ${name} ${detail}`)
  }
}

await browser.close()
process.exit(failed ? 1 : 0)