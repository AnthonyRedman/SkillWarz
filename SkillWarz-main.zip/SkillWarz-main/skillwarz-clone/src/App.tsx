import { Suspense, useEffect } from 'react'
import { Canvas } from '@react-three/fiber'
import { Physics } from '@react-three/rapier'
import Arena from './components/Map/Arena'
import Lighting from './components/Map/Lighting'
import Pickups from './components/Map/Pickups'
import Targets from './components/Map/Targets'
import Player from './components/Player/Player'
import PlayerCamera from './components/Player/PlayerCamera'
import PlayerControls from './components/Player/PlayerControls'
import WeaponManager from './components/Weapons/WeaponManager'
import NetSync from './net/NetSync'
import NetStateBridge from './net/NetStateBridge'
import RemotePlayers from './net/RemotePlayers'
import DamageFlash from './components/UI/DamageFlash'
import DeathOverlay from './components/UI/DeathOverlay'
import HUD from './components/UI/HUD'
import KillFeed from './components/UI/KillFeed'
import Menu from './components/UI/Menu'
import Scoreboard from './components/UI/Scoreboard'
import { useGame } from './store/gameStore'
import { useAuth } from './store/authStore'
import { CAMERA } from '@shared/constants'
import { FIXED_TIMESTEP } from '@shared/timestep'

export default function App() {
  const started = useGame((s) => s.started)
  const paused = useGame((s) => s.paused)
  const toggleNight = useGame((s) => s.toggleNight)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'KeyN' && !e.repeat) toggleNight()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [toggleNight])

  useEffect(() => {
    void useAuth.getState().init()
  }, [])

  return (
    <div className="game-root">
      <Canvas
        shadows
        camera={{ fov: CAMERA.fov, near: CAMERA.near, far: CAMERA.far, position: [0, 1.8, 19] }}
      >
        <Suspense fallback={null}>
          <PlayerControls>
            <Physics gravity={[0, -20, 0]} timeStep={FIXED_TIMESTEP}>
              <Lighting />
              <Arena />
              <Pickups />
              <Targets />
              <Player />
              <PlayerCamera />
              <WeaponManager />
              <NetSync />
              <NetStateBridge />
              <RemotePlayers />
            </Physics>
          </PlayerControls>
        </Suspense>
      </Canvas>
      {started && !paused && (
        <div className="crosshair">
          <span className="ch-h" />
          <span className="ch-v" />
        </div>
      )}
      {started && !paused && <HUD />}
      {started && !paused && <KillFeed />}
      <Menu />
      {started && <Scoreboard />}
      <DamageFlash />
      {started && <DeathOverlay />}
    </div>
  )
}