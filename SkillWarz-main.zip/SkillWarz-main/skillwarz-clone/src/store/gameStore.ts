import { create } from 'zustand'
import type { WeaponName } from '@shared/weapons'
import type { Difficulty } from '@shared/constants'

export interface KillMsg {
  id: number
  time: number
  text: string
  kind: 'kill' | 'death'
}

type GameState = {
  started: boolean
  paused: boolean
  night: boolean
  difficulty: Difficulty
  health: number
  maxHealth: number
  armor: number
  ammo: number
  maxAmmo: number
  weapon: WeaponName
  score: number
  kills: number
  deaths: number
  time: number
  dead: boolean
  killFeed: KillMsg[]
  start: () => void
  pause: () => void
  resume: () => void
  setDead: (dead: boolean) => void
  syncCombat: (combat: {
    health: number
    maxHealth: number
    score: number
    kills: number
    deaths: number
    isBot: boolean
  }) => void
  takeDamage: (amount: number) => void
  addHealth: (amount: number) => void
  addArmor: (amount: number) => void
  addAmmo: (amount: number) => void
  consumeAmmo: (amount: number) => void
  setAmmo: (ammo: number, max: number) => void
  setWeapon: (weapon: WeaponName) => void
  toggleNight: () => void
  setDifficulty: (difficulty: Difficulty) => void
  addScore: (points: number) => void
  addKill: () => void
  addDeath: () => void
  respawn: () => void
  tickTime: (delta: number) => void
  pushKillFeed: (msg: Omit<KillMsg, 'id' | 'time'>) => void
  reset: () => void
}

const initialState = {
  started: false,
  paused: false,
  night: false,
  difficulty: 'normal' as Difficulty,
  health: 100,
  maxHealth: 100,
  armor: 0,
  ammo: 12,
  maxAmmo: 12,
  weapon: 'pistol' as WeaponName,
  score: 0,
  kills: 0,
  deaths: 0,
  time: 0,
  dead: false,
  killFeed: [] as KillMsg[],
}

let killFeedId = 0

export const useGame = create<GameState>((set) => ({
  ...initialState,
  start: () => set({ started: true, paused: false }),
  pause: () => set({ paused: true }),
  resume: () => set({ paused: false }),
  setDead: (dead) => set({ dead }),
  syncCombat: (combat) =>
    set((state) => ({
      health: combat.health,
      maxHealth: combat.maxHealth,
      score: combat.score,
      kills: combat.kills,
      deaths: combat.deaths,
      dead: state.dead,
    })),
  takeDamage: (amount) =>
    set((state) => {
      let armor = state.armor
      let health = state.health
      const remaining = Math.max(0, amount - armor)
      armor = Math.max(0, armor - amount)
      health = Math.max(0, health - remaining)
      return { armor, health }
    }),
  addHealth: (amount) =>
    set((state) => ({ health: Math.min(100, state.health + amount) })),
  addArmor: (amount) =>
    set((state) => ({ armor: Math.min(100, state.armor + amount) })),
  addAmmo: (amount) =>
    set((state) => ({ ammo: Math.min(state.maxAmmo, state.ammo + amount) })),
  consumeAmmo: (amount) =>
    set((state) => ({ ammo: Math.max(0, state.ammo - amount) })),
  setAmmo: (ammo, max) => set({ ammo, maxAmmo: max }),
  setWeapon: (weapon) => set({ weapon }),
  toggleNight: () => set((state) => ({ night: !state.night })),
  setDifficulty: (difficulty) => set({ difficulty }),
  addScore: (points) => set((state) => ({ score: state.score + points })),
  addKill: () => set((state) => ({ kills: state.kills + 1 })),
  addDeath: () => set((state) => ({ deaths: state.deaths + 1 })),
  respawn: () => set({ health: 100, armor: 0 }),
  tickTime: (delta) => set((state) => ({ time: state.time + delta })),
  pushKillFeed: (msg) =>
    set((state) => ({
      killFeed: [
        ...state.killFeed.slice(-4),
        { ...msg, id: ++killFeedId, time: Date.now() },
      ],
    })),
  reset: () => set({ ...initialState, killFeed: [...initialState.killFeed] }),
}))

if (import.meta.env.DEV) {
  ;(window as unknown as Record<string, unknown>).__skillwarzGame = useGame
}