import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

export interface AuthUser {
  id: string
  username: string
  email: string | null
  isGuest: boolean
}

export interface PlayerRecord {
  username: string
  totalKills: number
  totalDeaths: number
  totalScore: number
  bestScore: number
  matchesPlayed: number
  isGuest: boolean
}

interface LeaderboardPlayer {
  rank: number
  username: string
  totalKills: number
  totalDeaths: number
  totalScore: number
  bestScore: number
  matchesPlayed: number
  isGuest: boolean
}

const WS_URL: string = (import.meta.env.VITE_WS_URL as string | undefined) ?? 'ws://localhost:2567'
export const API_URL = WS_URL.replace(/^ws/, 'http')

type AuthState = {
  token: string | null
  user: AuthUser | null
  record: PlayerRecord | null
  leaderboard: LeaderboardPlayer[]
  status: 'idle' | 'loading' | 'ready'
  error: string | null
  init: () => Promise<void>
  register: (username: string, email: string, password: string) => Promise<boolean>
  login: (email: string, password: string) => Promise<boolean>
  guest: () => Promise<boolean>
  logout: () => Promise<void>
  refreshLeaderboard: () => Promise<void>
  refreshRecord: () => Promise<void>
}

async function authedFetch(
  path: string,
  token: string | null,
  init?: RequestInit,
): Promise<Response> {
  const headers = new Headers(init?.headers)
  if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json')
  if (token) headers.set('Authorization', `Bearer ${token}`)
  return fetch(`${API_URL}${path}`, { ...init, headers })
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      record: null,
      leaderboard: [],
      status: 'idle',
      error: null,

      init: async () => {
        if (get().status === 'loading') return
        set({ status: 'loading', error: null })
        const token = get().token
        if (!token) {
          await get().guest()
          return
        }
        try {
          const res = await authedFetch('/api/auth/me', token)
          if (res.ok) {
            const body = (await res.json()) as { user: AuthUser; record: PlayerRecord | null }
            set({ user: body.user, record: body.record, status: 'ready' })
          } else {
            await get().guest()
          }
        } catch {
          set({ status: 'ready' })
        }
        await get().refreshLeaderboard()
      },

      register: async (username, email, password) => {
        set({ error: null })
        try {
          const res = await fetch(`${API_URL}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password }),
          })
          if (!res.ok) {
            const body = (await res.json().catch(() => null)) as { error?: string } | null
            set({ error: body?.error ?? 'registration failed' })
            return false
          }
          const body = (await res.json()) as { user: AuthUser; token: string }
          set({ token: body.token, user: body.user, status: 'ready' })
          await get().refreshLeaderboard()
          await get().refreshRecord()
          return true
        } catch {
          set({ error: 'could not reach server' })
          return false
        }
      },

      login: async (email, password) => {
        set({ error: null })
        try {
          const res = await fetch(`${API_URL}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          })
          if (!res.ok) {
            const body = (await res.json().catch(() => null)) as { error?: string } | null
            set({ error: body?.error ?? 'login failed' })
            return false
          }
          const body = (await res.json()) as { user: AuthUser; token: string }
          set({ token: body.token, user: body.user, status: 'ready' })
          await get().refreshLeaderboard()
          await get().refreshRecord()
          return true
        } catch {
          set({ error: 'could not reach server' })
          return false
        }
      },

      guest: async () => {
        try {
          const res = await fetch(`${API_URL}/api/auth/guest`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({}),
          })
          if (!res.ok) throw new Error('guest auth failed')
          const body = (await res.json()) as { user: AuthUser; token: string }
          set({ token: body.token, user: body.user, status: 'ready', error: null })
          await get().refreshLeaderboard()
          await get().refreshRecord()
          return true
        } catch {
          set({ status: 'ready' })
          return false
        }
      },

      logout: async () => {
        const { token } = get()
        if (token) {
          await authedFetch('/api/auth/logout', token, { method: 'POST' }).catch(() => undefined)
        }
        set({ token: null, user: null, record: null })
        await get().guest()
      },

      refreshLeaderboard: async () => {
        const token = get().token
        try {
          const res = await authedFetch('/api/leaderboard?limit=15&guests=1', token)
          if (res.ok) {
            const body = (await res.json()) as { players: LeaderboardPlayer[] }
            set({ leaderboard: body.players })
          }
        } catch {
          // leaderboard is non-critical
        }
      },

      refreshRecord: async () => {
        const token = get().token
        if (!token) return
        try {
          const res = await authedFetch('/api/auth/me', token)
          if (res.ok) {
            const body = (await res.json()) as { record: PlayerRecord | null }
            set({ record: body.record })
          }
        } catch {
          // non-critical
        }
      },
    }),
    {
      name: 'skillwarz-auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ token: state.token, user: state.user, record: state.record }),
    },
  ),
)

if (import.meta.env.DEV) {
  ;(window as unknown as Record<string, unknown>).__skillwarzAuth = useAuth
}