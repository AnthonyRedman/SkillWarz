import * as THREE from 'three'
import type { Ray, World } from '@dimforge/rapier3d-compat'
import { applyDamage, combat, isGhostCollider } from './combat'
import { FIRE_RANGE, type WeaponDef } from '@shared/weapons'
import { useNet } from '../net/netStore'
import { PLAYER } from '@shared/constants'

interface RaycastNamespace {
  Ray: new (origin: THREE.Vector3, direction: THREE.Vector3) => Ray
}

const MUZZLE_OFFSET = 0.35
const BEGINNING = new THREE.Vector3(0, 0, 0)
const CAPSULE_HALF = PLAYER.capsuleHeight / 2
const HIT_RADIUS = PLAYER.radius + 0.05

export type BulletOwner = 'player' | 'bot'

export interface Bullet {
  position: THREE.Vector3
  dir: THREE.Vector3
  speed: number
  damage: number
  range: number
  traveled: number
  owner: BulletOwner
}

const pending: Bullet[] = []

export function spreadDirection(baseDir: THREE.Vector3, spread: number): THREE.Vector3 {
  const dir = baseDir.clone()
  if (spread <= 0) return dir
  const right = new THREE.Vector3().crossVectors(dir, THREE.Object3D.DEFAULT_UP)
  if (right.lengthSq() < 1e-8) {
    right.set(1, 0, 0)
  } else {
    right.normalize()
  }
  const up = new THREE.Vector3().crossVectors(right, dir).normalize()
  dir
    .addScaledVector(right, (Math.random() - 0.5) * spread)
    .addScaledVector(up, (Math.random() - 0.5) * spread)
    .normalize()
  return dir
}

export function spawnBulletFromCamera(
  camera: THREE.PerspectiveCamera,
  def: WeaponDef,
  owner: BulletOwner = 'player',
): void {
  const origin = camera.position.clone()
  const baseDir = new THREE.Vector3()
  camera.getWorldDirection(baseDir)
  const count = Math.max(1, def.pellets)
  for (let i = 0; i < count; i++) {
    spawnBullet(origin, baseDir, def, owner)
  }
}

export function spawnBullet(
  origin: THREE.Vector3,
  baseDir: THREE.Vector3,
  def: WeaponDef,
  owner: BulletOwner = 'player',
): Bullet {
  const dir = spreadDirection(baseDir, def.spread)
  const bullet: Bullet = {
    position: origin.clone().addScaledVector(dir, MUZZLE_OFFSET),
    dir,
    speed: def.bulletSpeed,
    damage: def.damage,
    range: FIRE_RANGE,
    traveled: 0,
    owner,
  }
  pending.push(bullet)
  return bullet
}

export function drainPending(): Bullet[] {
  return pending.splice(0, pending.length)
}

function segSegDistance(
  p0: THREE.Vector3,
  p1: THREE.Vector3,
  q0: THREE.Vector3,
  q1: THREE.Vector3,
): { dist: number; t: number } {
  const u = p1.clone().sub(p0)
  const v = q1.clone().sub(q0)
  const w0 = q0.clone().sub(p0)
  const a = u.dot(u)
  const b = u.dot(v)
  const c = v.dot(v)
  const d = u.dot(w0)
  const e = v.dot(w0)
  const denom = a * c - b * b
  let s = 0
  let t = 0
  if (denom > 1e-8) {
    s = Math.max(0, Math.min(1, (b * e - c * d) / denom))
  } else {
    s = 0
  }
  t = Math.max(0, Math.min(1, (b * s + e) / Math.max(1e-8, c)))
  const w = w0.clone().addScaledVector(v, -t).addScaledVector(u, s)
  return { dist: w.length(), t: s }
}

function remoteHitDistance(bullet: Bullet): { dist: number; t: number } | null {
  const { players, selfId } = useNet.getState()
  let best: { dist: number; t: number } | null = null
  const p0 = bullet.position
  const p1 = p0.clone().addScaledVector(bullet.dir, bullet.speed)
  for (const id in players) {
    if (id === selfId) continue
    const player = players[id]
    if (player.health <= 0) continue
    const q0 = new THREE.Vector3(player.x, player.y - CAPSULE_HALF, player.z)
    const q1 = new THREE.Vector3(player.x, player.y + CAPSULE_HALF, player.z)
    const result = segSegDistance(p0, p1, q0, q1)
    if (result.dist <= HIT_RADIUS) {
      if (!best || result.t < best.t) best = { dist: result.dist, t: result.t }
    }
  }
  return best
}

export function stepBullets(
  list: Bullet[],
  dt: number,
  world: World,
  rapier: RaycastNamespace,
) {
  const impact = BEGINNING
  for (let i = list.length - 1; i >= 0; i--) {
    const bullet = list[i]
    const move = bullet.speed * dt

    const ray = new rapier.Ray(bullet.position, bullet.dir)
    const hit = world.castRay(
      ray,
      move + 0.02,
      true,
      undefined,
      undefined,
      undefined,
      undefined,
      (collider) => !isGhostCollider(collider.handle),
    )

    let distance = hit ? Math.min(hit.timeOfImpact, move) : Infinity
    let remote = false
    const rem = remoteHitDistance(bullet)
    if (rem) {
      const remDistance = rem.t * move
      if (remDistance <= distance) {
        distance = remDistance
        remote = true
      }
    }

    if (distance < Infinity) {
      impact
        .copy(bullet.position)
        .addScaledVector(bullet.dir, distance)
      if (remote) {
        combat.emitHitMarker()
      } else if (hit && applyDamage(hit.collider.handle, bullet.damage)) {
        combat.emitHitMarker()
      }
      combat.emitHit(impact.clone())
      list.splice(i, 1)
      continue
    }

    bullet.position.addScaledVector(bullet.dir, move)
    bullet.traveled += move
    if (bullet.traveled >= bullet.range) {
      list.splice(i, 1)
    }
  }
}