import * as THREE from 'three'

type DamageCallback = (damage: number) => void

const damageTargets = new Map<number, DamageCallback>()
const ghostColliders = new Set<number>()
const shotListeners = new Set<() => void>()
const hitListeners = new Set<(point: THREE.Vector3) => void>()
const playerHitListeners = new Set<(amount: number) => void>()
const hitMarkerListeners = new Set<() => void>()

export function setGhostCollider(handle: number, ghost: boolean) {
  if (ghost) ghostColliders.add(handle)
  else ghostColliders.delete(handle)
}

export function isGhostCollider(handle: number) {
  return ghostColliders.has(handle)
}

export const combat = {
  register(handle: number, callback: DamageCallback) {
    damageTargets.set(handle, callback)
  },
  unregister(handle: number) {
    damageTargets.delete(handle)
  },
  onShot(listener: () => void) {
    shotListeners.add(listener)
    return () => {
      shotListeners.delete(listener)
    }
  },
  onHit(listener: (point: THREE.Vector3) => void) {
    hitListeners.add(listener)
    return () => {
      hitListeners.delete(listener)
    }
  },
  onPlayerHit(listener: (amount: number) => void) {
    playerHitListeners.add(listener)
    return () => {
      playerHitListeners.delete(listener)
    }
  },
  onHitMarker(listener: () => void) {
    hitMarkerListeners.add(listener)
    return () => {
      hitMarkerListeners.delete(listener)
    }
  },
  emitShot() {
    shotListeners.forEach((listener) => listener())
  },
  emitHit(point: THREE.Vector3) {
    hitListeners.forEach((listener) => listener(point.clone()))
  },
  emitHitMarker() {
    hitMarkerListeners.forEach((listener) => listener())
  },
}

export function emitPlayerHit(amount: number) {
  playerHitListeners.forEach((listener) => listener(amount))
}

export function applyDamage(handle: number, amount: number): boolean {
  const callback = damageTargets.get(handle)
  if (callback) {
    callback(amount)
    return true
  }
  return false
}