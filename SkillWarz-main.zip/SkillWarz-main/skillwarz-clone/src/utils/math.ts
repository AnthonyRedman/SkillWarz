import * as THREE from 'three'

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t
}

export function moveTowards(current: number, target: number, delta: number): number {
  if (Math.abs(target - current) <= delta) return target
  return current + Math.sign(target - current) * delta
}

export function vectorFromEulerRotation(euler: THREE.Euler, isYawOnly = true): THREE.Vector3 {
  const vector = new THREE.Vector3()
  if (isYawOnly) {
    return new THREE.Vector3(
      -Math.sin(euler.y),
      0,
      -Math.cos(euler.y),
    )
  }
  vector.setFromMatrixColumn(
    new THREE.Matrix4().makeRotationFromEuler(euler),
    0,
  )
  return vector
}