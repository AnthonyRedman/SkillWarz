import type { WeaponName } from '@shared/weapons'

let ctx: AudioContext | null = null
let master: GainNode | null = null
let noiseBuffer: AudioBuffer | null = null

function ensure(): AudioContext | null {
  if (typeof window === 'undefined') return null
  if (!ctx) {
    const AC = window.AudioContext ?? (window as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext
    if (!AC) return null
    ctx = new AC()
    master = ctx.createGain()
    master.gain.value = 0.5
    master.connect(ctx.destination)
  }
  if (ctx.state === 'suspended') void ctx.resume()
  return ctx
}

function getNoise(c: AudioContext): AudioBuffer {
  if (!noiseBuffer) {
    const len = c.sampleRate * 0.5
    noiseBuffer = c.createBuffer(1, len, c.sampleRate)
    const data = noiseBuffer.getChannelData(0)
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
  }
  return noiseBuffer
}

function burst(
  c: AudioContext,
  at: number,
  dur: number,
  filterFreq: number,
  gain: number,
) {
  if (!master) return
  const src = c.createBufferSource()
  src.buffer = getNoise(c)
  src.loop = true
  const filter = c.createBiquadFilter()
  filter.type = 'lowpass'
  filter.frequency.setValueAtTime(filterFreq, at)
  const g = c.createGain()
  g.gain.setValueAtTime(gain, at)
  g.gain.exponentialRampToValueAtTime(0.0001, at + dur)
  src.connect(filter)
  filter.connect(g)
  g.connect(master)
  src.start(at)
  src.stop(at + dur + 0.01)
}

function tone(
  c: AudioContext,
  at: number,
  dur: number,
  from: number,
  to: number,
  gain: number,
  type: OscillatorType = 'sine',
) {
  if (!master) return
  const osc = c.createOscillator()
  osc.type = type
  osc.frequency.setValueAtTime(from, at)
  osc.frequency.exponentialRampToValueAtTime(Math.max(1, to), at + dur)
  const g = c.createGain()
  g.gain.setValueAtTime(gain, at)
  g.gain.exponentialRampToValueAtTime(0.0001, at + dur)
  osc.connect(g)
  g.connect(master)
  osc.start(at)
  osc.stop(at + dur + 0.01)
}

const SHOT_PROFILE: Record<WeaponName, { noiseDur: number; filter: number; gain: number; body: number }> = {
  pistol: { noiseDur: 0.07, filter: 3200, gain: 0.7, body: 140 },
  rifle: { noiseDur: 0.09, filter: 2600, gain: 0.65, body: 110 },
  shotgun: { noiseDur: 0.22, filter: 1200, gain: 0.85, body: 65 },
}

const GUNSHOT_GAIN = 0.5

export const audio = {
  gunshot(weapon: WeaponName) {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    const prof = SHOT_PROFILE[weapon]
    burst(c, now, prof.noiseDur, prof.filter, prof.gain * GUNSHOT_GAIN)
    tone(c, now, prof.noiseDur * 1.1, prof.body * 3, prof.body, 0.35 * GUNSHOT_GAIN, 'triangle')
  },
  botShot() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    burst(c, now, 0.06, 2400, 0.35)
    tone(c, now, 0.07, 150 * 3, 150, 0.22 * GUNSHOT_GAIN, 'triangle')
  },
  hit() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.03, 2400, 1900, 0.5, 'square')
  },
  hurt() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.18, 220, 120, 0.5, 'sawtooth')
    burst(c, now, 0.12, 600, 0.3)
  },
  killFromBot() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.5, 700, 90, 0.5, 'sawtooth')
    burst(c, now + 0.1, 0.3, 900, 0.35)
  },
  death() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.6, 260, 40, 0.55, 'sawtooth')
    burst(c, now, 0.5, 700, 0.4)
  },
  footstep(run: boolean) {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    burst(c, now, run ? 0.07 : 0.05, 420, run ? 0.22 : 0.16)
  },
  jump() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.15, 200, 340, 0.18, 'sine')
  },
  land() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    burst(c, now, 0.08, 380, 0.2)
  },
  reload() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    burst(c, now, 0.04, 1400, 0.18)
    burst(c, now + 0.18, 0.05, 1000, 0.2)
  },
  pickup() {
    const c = ensure()
    if (!c) return
    const now = c.currentTime
    tone(c, now, 0.12, 660, 880, 0.35, 'sine')
    tone(c, now + 0.09, 0.14, 880, 1320, 0.3, 'sine')
  },
}