import type { RapierRigidBody } from '@react-three/rapier'

export const playerRigidBody: { current: RapierRigidBody | null } = { current: null }