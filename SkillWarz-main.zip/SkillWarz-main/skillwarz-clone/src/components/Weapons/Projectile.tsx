import { useEffect, useState } from 'react'
import { combat } from '../../utils/combat'
import type { Vector3 } from 'three'

interface Impact {
  id: number
  pos: [number, number, number]
}

export default function Projectile() {
  const [impacts, setImpacts] = useState<Impact[]>([])

  useEffect(() => {
    let nextId = 0
    const off = combat.onHit((point: Vector3) => {
      const id = nextId++
      const entry: Impact = { id, pos: [point.x, point.y, point.z] }
      setImpacts((list) => [...list, entry])
      setTimeout(() => {
        setImpacts((list) => list.filter((e) => e.id !== id))
      }, 200)
    })
    return off
  }, [])

  return (
    <>
      {impacts.map((e) => (
        <group key={e.id} position={e.pos}>
          <mesh>
            <sphereGeometry args={[0.09, 8, 8]} />
            <meshBasicMaterial color="#fff2c9" toneMapped={false} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.2, 8, 8]} />
            <meshBasicMaterial
              color="#ff8c42"
              toneMapped={false}
              transparent
              opacity={0.35}
            />
          </mesh>
        </group>
      ))}
    </>
  )
}