import { useEffect, useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { useWeapon } from '../../hooks/useWeapon'
import { WEAPONS, type WeaponName } from '@shared/weapons'
import { useGame } from '../../store/gameStore'
import Bullets from './Bullets'
import Gun from './Gun'
import Projectile from './Projectile'

const ORDER: WeaponName[] = ['pistol', 'rifle', 'shotgun']

export default function WeaponManager() {
  const [active, setActive] = useState<WeaponName>('pistol')
  const weapon = useWeapon(WEAPONS[active])
  const firing = useRef(false)

  const setActiveWeapon = (w: WeaponName) => {
    setActive(w)
    useGame.getState().setWeapon(w)
  }

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (e.button === 0 && document.pointerLockElement) {
        firing.current = true
      }
    }
    const onUp = (e: MouseEvent) => {
      if (e.button === 0) firing.current = false
    }
    const onWheel = (e: WheelEvent) => {
      if (!document.pointerLockElement) return
      const idx = ORDER.indexOf(active)
      const dir = e.deltaY > 0 ? 1 : -1
      setActiveWeapon(ORDER[(idx + dir + ORDER.length) % ORDER.length])
    }
    const onKey = (e: KeyboardEvent) => {
      const state = useGame.getState()
      if (!state.started || state.paused) return
      const idx = ['Digit1', 'Digit2', 'Digit3'].indexOf(e.code)
      if (idx >= 0) setActiveWeapon(ORDER[idx])
    }
    window.addEventListener('mousedown', onDown)
    window.addEventListener('mouseup', onUp)
    window.addEventListener('wheel', onWheel)
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('mousedown', onDown)
      window.removeEventListener('mouseup', onUp)
      window.removeEventListener('wheel', onWheel)
      window.removeEventListener('keydown', onKey)
    }
  }, [active])

  useFrame((_: unknown, delta: number) => {
    weapon.setCooldown(delta)
    if (firing.current) weapon.fire()
  })

  const def = WEAPONS[active]

  return (
    <>
      <Gun key={def.name} def={def} />
      <Bullets />
      <Projectile />
    </>
  )
}