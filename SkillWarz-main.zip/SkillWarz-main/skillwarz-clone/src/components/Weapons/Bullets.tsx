import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useRapier } from '@react-three/rapier'
import * as THREE from 'three'
import { drainPending, stepBullets, type Bullet } from '../../utils/projectiles'
import { clampDelta } from '@shared/timestep'

const MAX_BULLETS = 48
const FORWARD = new THREE.Vector3(0, 0, 1)
const ORIENT = new THREE.Quaternion()

const bulletMaterial = new THREE.MeshBasicMaterial({
  color: '#7dd3fc',
  toneMapped: false,
  transparent: true,
  opacity: 0.95,
})

export default function Bullets() {
  const { world, rapier } = useRapier()
  const bulletsRef = useRef<Bullet[]>([])
  const meshRefs = useRef<(THREE.Mesh | null)[]>([])

  useFrame((_, delta) => {
    const dt = clampDelta(delta)
    const bullets = bulletsRef.current
    bullets.push(...drainPending())
    stepBullets(bullets, dt, world, rapier)

    for (let i = 0; i < MAX_BULLETS; i++) {
      const mesh = meshRefs.current[i]
      if (!mesh) continue
      const bullet = bullets[i]
      if (bullet) {
        mesh.visible = true
        mesh.position.copy(bullet.position)
        ORIENT.setFromUnitVectors(FORWARD, bullet.dir)
        mesh.quaternion.copy(ORIENT)
      } else {
        mesh.visible = false
      }
    }
  })

  return (
    <group>
      {Array.from({ length: MAX_BULLETS }, (_, i) => (
        <mesh
          key={i}
          ref={(el) => {
            meshRefs.current[i] = el
          }}
          material={bulletMaterial}
          visible={false}
        >
          <boxGeometry args={[0.05, 0.05, 0.5]} />
        </mesh>
      ))}
    </group>
  )
}