import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import type * as THREE from 'three'
import { combat } from '../../utils/combat'
import type { WeaponDef } from '@shared/weapons'

function WeaponShape({ def }: { def: WeaponDef }) {
  const { shape } = def

  if (def.name === 'rifle') {
    return (
      <group>
        <mesh castShadow position={[0, 0, -0.08]}>
          <boxGeometry args={[shape.bodyW, shape.bodyH, shape.bodyL]} />
          <meshStandardMaterial color={def.color} metalness={0.5} roughness={0.45} />
        </mesh>
        <mesh castShadow position={[0, 0.01, -0.36]}>
          <boxGeometry args={[shape.barrelW, shape.barrelH, shape.barrelL]} />
          <meshStandardMaterial color="#3a3f46" metalness={0.7} roughness={0.35} />
        </mesh>
        {shape.stock > 0 && (
          <mesh castShadow position={[0, -0.02, 0.2]}>
            <boxGeometry args={[0.06, shape.bodyH * 0.9, shape.stock]} />
            <meshStandardMaterial color="#3a3f46" metalness={0.3} roughness={0.7} />
          </mesh>
        )}
        {shape.magH > 0 && (
          <mesh castShadow position={[0, -0.1, 0.03]} rotation={[0.15, 0, 0]}>
            <boxGeometry args={[0.05, shape.magH, 0.22]} />
            <meshStandardMaterial color="#3a3f46" metalness={0.5} roughness={0.5} />
          </mesh>
        )}
        <mesh castShadow position={[0, shape.bodyH * 0.52, -0.08]}>
          <boxGeometry args={[0.03, 0.03, 0.16]} />
          <meshStandardMaterial color={def.accent} emissive={def.accent} emissiveIntensity={0.3} />
        </mesh>
        <mesh position={[0, 0.035, 0.04]}>
          <boxGeometry args={[shape.bodyW * 0.7, 0.015, 0.14]} />
          <meshStandardMaterial
            color={def.accent}
            emissive={def.accent}
            emissiveIntensity={0.5}
          />
        </mesh>
      </group>
    )
  }

  if (def.name === 'shotgun') {
    return (
      <group>
        <mesh castShadow position={[0, 0, -0.05]}>
          <boxGeometry args={[shape.bodyW, shape.bodyH, shape.bodyL]} />
          <meshStandardMaterial color={def.color} metalness={0.3} roughness={0.8} />
        </mesh>
        <mesh castShadow position={[0, 0.01, -0.38]}>
          <boxGeometry args={[shape.barrelW, shape.barrelH, shape.barrelL]} />
          <meshStandardMaterial color="#3a3f46" metalness={0.6} roughness={0.4} />
        </mesh>
        <mesh castShadow position={[0, -0.035, -0.34]} rotation={[-0.5, 0, 0]}>
          <boxGeometry args={[shape.barrelW * 1.9, 0.05, 0.3]} />
          <meshStandardMaterial color="#23262b" roughness={0.6} />
        </mesh>
        {shape.stock > 0 && (
          <mesh castShadow position={[0, 0.02, 0.23]} rotation={[0, 0, -1.5]}>
            <boxGeometry args={[0.07, shape.stock, 0.09]} />
            <meshStandardMaterial color="#3a301f" roughness={0.85} />
          </mesh>
        )}
        <mesh position={[0, 0.06, 0.05]}>
          <boxGeometry args={[0.05, 0.02, 0.1]} />
          <meshStandardMaterial
            color={def.accent}
            emissive={def.accent}
            emissiveIntensity={0.4}
          />
        </mesh>
      </group>
    )
  }

  return (
    <group>
      <mesh castShadow position={[0, 0, -0.05]}>
        <boxGeometry args={[shape.bodyW, shape.bodyH, shape.bodyL]} />
        <meshStandardMaterial color={def.color} metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh castShadow position={[0, 0.025, -0.28]}>
        <boxGeometry args={[shape.barrelW, shape.barrelH, shape.barrelL]} />
        <meshStandardMaterial color="#3a3f46" metalness={0.6} roughness={0.4} />
      </mesh>
      {shape.magH > 0 && (
        <mesh castShadow position={[0, -0.1, 0.05]}>
          <boxGeometry args={[shape.bodyW * 0.8, shape.magH, shape.bodyL * 0.24]} />
          <meshStandardMaterial color="#23262b" />
        </mesh>
      )}
      <mesh position={[0, 0.085, 0.02]}>
        <boxGeometry args={[0.06, 0.03, 0.12]} />
        <meshStandardMaterial
          color={def.accent}
          emissive={def.accent}
          emissiveIntensity={0.4}
        />
      </mesh>
    </group>
  )
}

export default function Gun({ def }: { def: WeaponDef }) {
  const camera = useThree((s) => s.camera)
  const group = useRef<THREE.Group>(null)
  const kick = useRef(0)

  useEffect(() => {
    return combat.onShot(() => {
      kick.current = def.recoil
    })
  }, [def])

  useFrame((_: unknown, delta: number) => {
    if (kick.current > 0) {
      kick.current *= Math.exp(-delta * 9)
      if (kick.current < 0.001) kick.current = 0
    }
    if (group.current) {
      group.current.position.z = def.holdZ + kick.current
    }
  })

  return (
    <primitive object={camera}>
      <group ref={group} position={[def.holdX, def.holdY, def.holdZ]}>
        <WeaponShape def={def} />
      </group>
    </primitive>
  )
}