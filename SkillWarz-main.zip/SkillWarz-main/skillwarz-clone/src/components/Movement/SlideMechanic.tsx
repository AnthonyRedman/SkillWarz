export default function SlideMechanic() {
  return null
}