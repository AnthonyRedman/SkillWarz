export default function Teleporter() {
  return null
}