export default function BouncePad() {
  return null
}