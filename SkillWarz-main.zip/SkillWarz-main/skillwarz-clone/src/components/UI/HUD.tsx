import { useEffect } from 'react'
import { useGame } from '../../store/gameStore'
import { useNet } from '../../net/netStore'
import { WEAPONS } from '@shared/weapons'

function formatTime(t: number) {
  const m = Math.floor(t / 60)
  const s = Math.floor(t % 60)
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
}

export default function HUD() {
  const health = useGame((s) => s.health)
  const ammo = useGame((s) => s.ammo)
  const maxAmmo = useGame((s) => s.maxAmmo)
  const weapon = useGame((s) => s.weapon)
  const kills = useGame((s) => s.kills)
  const deaths = useGame((s) => s.deaths)
  const score = useGame((s) => s.score)
  const time = useGame((s) => s.time)
  const netStatus = useNet((s) => s.status)
  const online = useNet((s) => Object.keys(s.players).length)

  useEffect(() => {
    const id = setInterval(() => {
      const state = useGame.getState()
      if (state.started && !state.paused) state.tickTime(0.1)
    }, 100)
    return () => clearInterval(id)
  }, [])

  const hp = Math.max(0, Math.min(100, health))
  const def = WEAPONS[weapon]

  return (
    <div className="hud">
      <div className="hud-top">
        <div className="stat-block kills">{kills}</div>
        <div className="stat-block deaths">{deaths}</div>
        <div className="stat-block score">{score}</div>
      </div>

      <div className="hud-center-top">{formatTime(time)}</div>

      <div className={`hud-net net-${netStatus}`}>
        {netStatus === 'online'
          ? `ONLINE · ${online}`
          : netStatus === 'connecting'
            ? 'CONNECTING'
            : 'OFFLINE'}
      </div>

      <div className="hud-bottom">
        <div className="hud-left">
          <div className="hp-row">
            <span className="hp-label">HP</span>
            <div className="hp-bar">
              <div className="hp-fill" style={{ width: `${hp}%` }} />
            </div>
            <span className="hp-num">{hp}</span>
          </div>
        </div>

        <div className="hud-right">
          <div className="weapon-name">{def.label}</div>
          <div className="ammo-row">
            <span className="ammo-current">{ammo}</span>
            <span className="ammo-max">/ {maxAmmo}</span>
          </div>
        </div>
      </div>
    </div>
  )
}