import { useState } from 'react'
import { useAuth } from '../../store/authStore'

type Mode = 'guest' | 'login' | 'register'

export default function AuthPanel() {
  const user = useAuth((s) => s.user)
  const record = useAuth((s) => s.record)
  const error = useAuth((s) => s.error)
  const status = useAuth((s) => s.status)
  const register = useAuth((s) => s.register)
  const login = useAuth((s) => s.login)
  const guest = useAuth((s) => s.guest)
  const logout = useAuth((s) => s.logout)

  const [mode, setMode] = useState<Mode>('guest')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true)
    try {
      if (mode === 'register') {
        await register(username, email, password)
      } else if (mode === 'login') {
        await login(email, password)
      } else {
        await guest()
      }
    } finally {
      setBusy(false)
    }
  }

  if (status === 'loading') {
    return <p className="auth-status">Loading account…</p>
  }

  if (user) {
    return (
      <div className="auth-panel">
        <div className="auth-user">
          <span className="auth-name">{user.username}</span>
          {user.isGuest && <span className="auth-tag">guest</span>}
          {!user.isGuest && <span className="auth-tag auth-tag-account">account</span>}
        </div>
        {record && record.matchesPlayed > 0 && (
          <div className="auth-stats">
            <span>{record.matchesPlayed} matches</span>
            <span>{record.totalKills} kills</span>
            <span>{record.totalScore} pts</span>
            <span>best {record.bestScore}</span>
          </div>
        )}
        {user.isGuest && (
          <p className="auth-hint">Sign in with an account to keep your score across devices.</p>
        )}
        <div className="auth-row">
          {!user.isGuest && (
            <button className="auth-btn auth-btn-secondary" onClick={() => void logout()}>
              LOG OUT
            </button>
          )}
          {user.isGuest && (
            <button
              className="auth-btn auth-btn-secondary"
              onClick={() => {
                setMode('register')
                setUsername(user.username)
              }}
            >
              SIGN UP
            </button>
          )}
        </div>
      </div>
    )
  }

  return (
    <form className="auth-panel" onSubmit={(e) => void submit(e)}>
      <div className="auth-tabs">
        <button
          type="button"
          className={`auth-tab${mode === 'guest' ? ' active' : ''}`}
          onClick={() => setMode('guest')}
        >
          GUEST
        </button>
        <button
          type="button"
          className={`auth-tab${mode === 'login' ? ' active' : ''}`}
          onClick={() => setMode('login')}
        >
          LOGIN
        </button>
        <button
          type="button"
          className={`auth-tab${mode === 'register' ? ' active' : ''}`}
          onClick={() => setMode('register')}
        >
          SIGN UP
        </button>
      </div>

      {mode === 'guest' ? (
        <>
          <p className="auth-hint">Play instantly without an account.</p>
          <button className="auth-btn" type="submit" disabled={busy}>
            {busy ? 'CONNECTING…' : 'PLAY AS GUEST'}
          </button>
        </>
      ) : (
        <>
          {mode === 'register' && (
            <input
              className="auth-input"
              type="text"
              placeholder="Username"
              value={username}
              maxLength={24}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          )}
          <input
            className="auth-input"
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            className="auth-input"
            type="password"
            placeholder="Password"
            value={password}
            minLength={6}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button className="auth-btn" type="submit" disabled={busy}>
            {busy ? '…' : mode === 'register' ? 'CREATE ACCOUNT' : 'LOG IN'}
          </button>
        </>
      )}

      {error && <p className="auth-error">{error}</p>}
    </form>
  )
}