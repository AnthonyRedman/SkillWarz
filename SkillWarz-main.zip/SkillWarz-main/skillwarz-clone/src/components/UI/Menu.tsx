import { useState } from 'react'
import { useGame } from '../../store/gameStore'
import { connectNet } from '../../net/network'
import { useNet } from '../../net/netStore'
import { DIFFICULTY, type Difficulty } from '@shared/constants'
import AuthPanel from './AuthPanel'
import Leaderboard from './Leaderboard'

function lockPointer() {
  const canvas = document.querySelector('canvas')
  if (canvas && canvas.requestPointerLock) {
    canvas.requestPointerLock()
  }
}

const DIFFICULTY_ORDER: Difficulty[] = ['easy', 'normal', 'hard']

export default function Menu() {
  const started = useGame((s) => s.started)
  const paused = useGame((s) => s.paused)
  const difficulty = useGame((s) => s.difficulty)
  const setDifficulty = useGame((s) => s.setDifficulty)
  const netStatus = useNet((s) => s.status)
  const online = useNet((s) => Object.keys(s.players).length)
  const [step, setStep] = useState<'difficulty' | 'menu'>('difficulty')

  if (started && !paused) return null

  const onPlay = () => {
    void connectNet(difficulty)
    useGame.getState().start()
    lockPointer()
  }

  const onResume = () => {
    useGame.getState().resume()
    lockPointer()
  }

  const onSelect = (d: Difficulty) => {
    setDifficulty(d)
    setStep('menu')
  }

  return (
    <div className="menu-overlay">
      <div className="menu-card">
        {!started ? (
          step === 'difficulty' ? (
            <>
              <h1 className="menu-title">SKILLWARZ</h1>
              <p className="menu-sub">Choose your difficulty</p>
              <div className="difficulty-list">
                {DIFFICULTY_ORDER.map((d) => (
                  <button
                    key={d}
                    className={`difficulty-card${d === difficulty ? ' active' : ''}`}
                    onClick={() => onSelect(d)}
                  >
                    <span className="difficulty-card-label">{DIFFICULTY[d].label}</span>
                    <span className="difficulty-card-desc">{DIFFICULTY[d].description}</span>
                  </button>
                ))}
              </div>
              <AuthPanel />
              <Leaderboard />
              <button className="menu-btn menu-btn-secondary" onClick={() => onSelect('easy')}>
                SKIP TO PLAY
              </button>
            </>
          ) : (
            <>
              <h1 className="menu-title">SKILLWARZ</h1>
              <p className="menu-sub">
                Difficulty: {DIFFICULTY[difficulty].label} &middot; {' '}
                {DIFFICULTY[difficulty].description}
              </p>
              <div className="menu-controls">
                <span>WASD Move</span>
                <span>Shift Sprint</span>
                <span>LMB Shoot</span>
                <span>R Reload</span>
                <span>1/2/3 Weapons</span>
                <span>Scroll Switch</span>
                <span>C Slide</span>
                <span>Space Jump</span>
                <span>N Night Mode</span>
              </div>
              <p className={`menu-net net-${netStatus}`}>
                {netStatus === 'online'
                  ? `Multiplayer online · ${online} in room`
                  : netStatus === 'connecting'
                    ? 'Connecting to server…'
                    : netStatus === 'offline'
                      ? 'Server offline — bots run on the server. Start it and refresh.'
                      : 'Multiplayer will connect on play'}
              </p>
              <button className="menu-btn menu-btn-secondary" onClick={() => setStep('difficulty')}>
                CHOOSE DIFFICULTY
              </button>
              <button className="menu-btn" onClick={onPlay}>
                CLICK TO PLAY
              </button>
            </>
          )
        ) : (
          <>
            <h1 className="menu-title">PAUSED</h1>
            <p className="menu-sub">Take a breath. The bots will wait. Mostly.</p>
            <p className="menu-diff-label">
              Difficulty: {DIFFICULTY[difficulty].label}
            </p>
            <button className="menu-btn" onClick={onResume}>
              RESUME
            </button>
          </>
        )}
      </div>
    </div>
  )
}