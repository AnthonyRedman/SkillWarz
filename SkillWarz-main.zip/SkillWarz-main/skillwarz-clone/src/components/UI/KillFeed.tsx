import { useGame } from '../../store/gameStore'
import type { KillMsg } from '../../store/gameStore'

const FEED_SLICE = 5

export default function KillFeed() {
  const feed = useGame((s) => s.killFeed)

  if (feed.length === 0) return null

  return (
    <div className="kill-feed">
      {feed.slice(-FEED_SLICE).map((msg: KillMsg) => (
        <div key={msg.id} className={`feed-item feed-${msg.kind}`}>
          {msg.text}
        </div>
      ))}
    </div>
  )
}