import { useEffect, useState } from 'react'
import { combat } from '../../utils/combat'

export default function DamageFlash() {
  const [flash, setFlash] = useState(false)

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | null = null
    const off = combat.onPlayerHit(() => {
      setFlash(true)
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => setFlash(false), 80)
    })
    return () => {
      off()
      if (timer) clearTimeout(timer)
    }
  }, [])

  if (!flash) return null
  return <div className="dmg-flash" />
}