import { useEffect, useState } from 'react'
import { useGame } from '../../store/gameStore'
import { useNet } from '../../net/netStore'

export default function Scoreboard() {
  const [open, setOpen] = useState(false)
  const selfId = useNet((s) => s.selfId)
  const players = useNet((s) => s.players)
  const score = useGame((s) => s.score)
  const kills = useGame((s) => s.kills)
  const deaths = useGame((s) => s.deaths)

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        e.preventDefault()
        setOpen(true)
      }
    }
    const up = (e: KeyboardEvent) => {
      if (e.code === 'Tab') setOpen(false)
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    window.addEventListener('blur', () => setOpen(false))
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', () => setOpen(false))
    }
  }, [])

  if (!open) return null

  const online = Object.values(players).length > 0
  const rows = Object.values(players)
    .sort((a, b) => b.score - a.score)
    .map((p) => {
      const ratio = p.deaths === 0 ? p.kills.toFixed(1) : (p.kills / p.deaths).toFixed(2)
      return {
        id: p.id,
        name: p.isBot ? `${p.name} <bot>` : p.name,
        score: p.score,
        kills: p.kills,
        deaths: p.deaths,
        ratio,
        isSelf: p.id === selfId,
      }
    })

  const fallbackRatio = deaths === 0 ? kills.toFixed(1) : (kills / deaths).toFixed(2)
  const self = rows.find((r) => r.isSelf) ??
    (!online
      ? { id: 'you', name: 'You', score, kills, deaths, ratio: fallbackRatio, isSelf: true }
      : undefined)

  return (
    <div className="scoreboard">
      <div className="scoreboard-title">SCOREBOARD</div>
      <table>
        <thead>
          <tr>
            <th>Player</th>
            <th>Score</th>
            <th>Kills</th>
            <th>Deaths</th>
            <th>K/D</th>
          </tr>
        </thead>
        <tbody>
          {self && (
            <tr className="sb-self">
              <td>{self.name}</td>
              <td>{self.score}</td>
              <td>{self.kills}</td>
              <td>{self.deaths}</td>
              <td>{self.ratio}</td>
            </tr>
          )}
          {rows
            .filter((r) => !r.isSelf)
            .map((r) => (
              <tr key={r.id}>
                <td>{r.name}</td>
                <td>{r.score}</td>
                <td>{r.kills}</td>
                <td>{r.deaths}</td>
                <td>{r.ratio}</td>
              </tr>
            ))}
        </tbody>
      </table>
      <div className="scoreboard-hint">Hold TAB to view · {score} pts</div>
    </div>
  )
}