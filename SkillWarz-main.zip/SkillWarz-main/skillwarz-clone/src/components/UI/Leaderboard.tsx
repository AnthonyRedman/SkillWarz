import { useEffect } from 'react'
import { useAuth } from '../../store/authStore'

export default function Leaderboard() {
  const players = useAuth((s) => s.leaderboard)
  const refreshLeaderboard = useAuth((s) => s.refreshLeaderboard)

  useEffect(() => {
    void refreshLeaderboard()
    const interval = setInterval(() => {
      void refreshLeaderboard()
    }, 15000)
    return () => clearInterval(interval)
  }, [refreshLeaderboard])

  if (!players.length) {
    return (
      <div className="leaderboard">
        <div className="leaderboard-title">LEADERBOARD</div>
        <p className="leaderboard-empty">No scores yet. Play a match!</p>
      </div>
    )
  }

  return (
    <div className="leaderboard">
      <div className="leaderboard-title">LEADERBOARD</div>
      <table className="leaderboard-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Player</th>
            <th>Kills</th>
            <th>Score</th>
            <th>Best</th>
            <th>Matches</th>
          </tr>
        </thead>
        <tbody>
          {players.map((p) => (
            <tr key={`${p.rank}-${p.username}`}>
              <td className="lb-rank">{p.rank}</td>
              <td className="lb-name">
                {p.username}
                {p.isGuest && <span className="lb-guest">guest</span>}
              </td>
              <td>{p.totalKills}</td>
              <td>{p.totalScore}</td>
              <td>{p.bestScore}</td>
              <td>{p.matchesPlayed}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}