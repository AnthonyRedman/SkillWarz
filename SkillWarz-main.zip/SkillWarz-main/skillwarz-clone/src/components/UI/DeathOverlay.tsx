import { useGame } from '../../store/gameStore'

export default function DeathOverlay() {
  const dead = useGame((s) => s.dead)
  if (!dead) return null
  return (
    <div className="death-overlay">
      <span>You died</span>
    </div>
  )
}