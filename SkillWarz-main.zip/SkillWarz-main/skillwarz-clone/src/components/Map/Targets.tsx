import { useEffect, useRef, useState } from 'react'
import { RigidBody, CuboidCollider } from '@react-three/rapier'
import type { Collider } from '@dimforge/rapier3d-compat'
import { combat, setGhostCollider } from '../../utils/combat'

const INITIAL_HP = 100
const RESPAWN_MS = 2500

interface TargetProps {
  position: [number, number, number]
}

function Target({ position }: TargetProps) {
  const colliderRef = useRef<Collider>(null)
  const [, setHp] = useState(INITIAL_HP)
  const [flash, setFlash] = useState(false)
  const [dead, setDead] = useState(false)

  useEffect(() => {
    const c = colliderRef.current
    if (!c) return
    const handle = c.handle
    if (dead) {
      setGhostCollider(handle, true)
      return () => setGhostCollider(handle, false)
    }
    combat.register(handle, (damage) => {
      setHp((prev) => {
        const next = prev - damage
        if (next <= 0) {
          setDead(true)
          setTimeout(() => {
            setHp(INITIAL_HP)
            setDead(false)
          }, RESPAWN_MS)
        }
        return Math.max(0, next)
      })
      setFlash(true)
      setTimeout(() => setFlash(false), 130)
    })
    return () => combat.unregister(handle)
  }, [dead])

  return (
    <RigidBody type="fixed" colliders={false} position={position}>
      <CuboidCollider ref={colliderRef} args={[0.6, 1.1, 0.3]} position={[0, 1.1, 0]} />
      {!dead && (
        <group>
          <mesh position={[0, 1.2, 0]} castShadow>
            <boxGeometry args={[1.2, 2.0, 0.2]} />
            <meshStandardMaterial
              color={flash ? '#ffffff' : '#e85d3a'}
              emissive={flash ? '#ffffff' : '#000000'}
              emissiveIntensity={flash ? 0.9 : 0}
              roughness={0.4}
            />
          </mesh>
          <mesh position={[0, 1.7, 0.101]}>
            <circleGeometry args={[0.4, 24]} />
            <meshBasicMaterial color="#fff6ea" />
          </mesh>
          <mesh position={[0, 1.7, 0.102]}>
            <circleGeometry args={[0.2, 24]} />
            <meshBasicMaterial color="#ff4d5e" />
          </mesh>
          <mesh position={[0, -0.55, 0]} castShadow>
            <boxGeometry args={[0.25, 1.3, 0.25]} />
            <meshStandardMaterial color="#3a3f46" metalness={0.5} roughness={0.5} />
          </mesh>
          <mesh position={[0, -1.1, 0]} rotation={[0, 0, Math.PI / 2]}>
            <cylinderGeometry args={[0.28, 0.28, 0.9, 8]} />
            <meshStandardMaterial color="#26292e" />
          </mesh>
        </group>
      )}
    </RigidBody>
  )
}

const positions: [number, number, number][] = [
  [18, 0, -14],
  [-18, 0, -14],
  [20, 0, 4],
  [-20, 0, 4],
  [16, 0, 10],
]

export default function Targets() {
  return (
    <>
      {positions.map((pos, i) => (
        <Target key={i} position={pos} />
      ))}
    </>
  )
}