import { useRef, useState } from 'react'
import { useFrame } from '@react-three/fiber'
import { CuboidCollider, RigidBody } from '@react-three/rapier'
import type { RapierRigidBody } from '@react-three/rapier'
import * as THREE from 'three'
import { useGame } from '../../store/gameStore'
import { playerRigidBody } from '../../utils/playerSystem'
import { audio } from '../../utils/audio'
import { COLORS } from '@shared/constants'
import { clampDelta } from '@shared/timestep'

type PickupKind = 'health' | 'ammo'

interface PickupProps {
  kind: PickupKind
  position: [number, number, number]
  amount: number
}

const RESPAWN_TIME = 8

function collect(kind: PickupKind, amount: number, respawn: () => void) {
  const state = useGame.getState()
  if (!state.started || state.paused) return
  if (kind === 'health') {
    if (state.health >= 100) return
    state.addHealth(amount)
  } else {
    if (state.ammo >= state.maxAmmo) return
    state.addAmmo(amount)
  }
  audio.pickup()
  respawn()
}

function PickupMesh({ kind }: { kind: PickupKind }) {
  const group = useRef<THREE.Group>(null)

  useFrame((_, rawDelta) => {
    const g = group.current
    if (!g) return
    const delta = clampDelta(rawDelta)
    g.rotation.y += delta * 1.2
    g.position.y += Math.sin(performance.now() / 400) * delta * 0.15
  })

  if (kind === 'health') {
    return (
      <group ref={group}>
        <mesh>
          <boxGeometry args={[0.5, 0.18, 0.5]} />
          <meshStandardMaterial
            color={COLORS.pickupHealth}
            emissive={COLORS.pickupHealth}
            emissiveIntensity={0.9}
            roughness={0.3}
          />
        </mesh>
        <mesh position={[0, 0.21, 0]}>
          <boxGeometry args={[0.12, 0.28, 0.12]} />
          <meshStandardMaterial
            color="#0a0c10"
            emissive={COLORS.pickupHealth}
            emissiveIntensity={1.6}
          />
        </mesh>
        <mesh position={[0, 0.21, 0]}>
          <boxGeometry args={[0.28, 0.12, 0.12]} />
          <meshStandardMaterial
            color="#0a0c10"
            emissive={COLORS.pickupHealth}
            emissiveIntensity={1.6}
          />
        </mesh>
      </group>
    )
  }

  return (
    <group ref={group}>
      <mesh>
        <boxGeometry args={[0.5, 0.34, 0.4]} />
        <meshStandardMaterial
          color={COLORS.pickupAmmo}
          emissive={COLORS.pickupAmmo}
          emissiveIntensity={0.9}
          roughness={0.35}
          metalness={0.4}
        />
      </mesh>
      <mesh position={[0, 0.03, 0.22]}>
        <boxGeometry args={[0.1, 0.2, 0.08]} />
        <meshStandardMaterial
          color="#0a0c10"
          emissive={COLORS.pickupAmmo}
          emissiveIntensity={1.2}
        />
      </mesh>
    </group>
  )
}

function Pickup({ kind, position, amount }: PickupProps) {
  const [active, setActive] = useState(true)
  const [scale, setScale] = useState(1)

  const respawn = () => {
    setScale(0)
    setTimeout(() => {
      setScale(1)
      setActive(true)
    }, RESPAWN_TIME * 1000)
  }

  const onIntersectionEnter = ({ other }: { other: { rigidBody?: RapierRigidBody | null } }) => {
    const body = other.rigidBody
    if (!body) return
    if (body === playerRigidBody.current) {
      setActive(false)
      collect(kind, amount, respawn)
    }
  }

  const baseY = position[1]

  return (
    <group position={[position[0], baseY, position[2]]}>
      {active && (
        <RigidBody type="fixed" colliders={false} onIntersectionEnter={onIntersectionEnter}>
          <CuboidCollider args={[0.7, 0.7, 0.7]} sensor />
        </RigidBody>
      )}
      {active && (
        <group scale={scale}>
          <PickupMesh kind={kind} />
        </group>
      )}
    </group>
  )
}

const healthSpots: [number, number, number][] = [
  [-6, 1.2, 6],
  [6, 1.2, -6],
  [0, 1.2, 8],
  [-28, 1.2, 10],
  [28, 1.2, -10],
]

const ammoSpots: [number, number, number][] = [
  [-12, 1.2, -12],
  [12, 1.2, 12],
  [28, 1.2, 8],
  [-28, 1.2, -8],
  [0, 1.2, -8],
]

export default function Pickups() {
  return (
    <>
      {healthSpots.map((pos, i) => (
        <Pickup key={`h${i}`} kind="health" position={pos} amount={25} />
      ))}
      {ammoSpots.map((pos, i) => (
        <Pickup key={`a${i}`} kind="ammo" position={pos} amount={20} />
      ))}
    </>
  )
}