import { RigidBody, CuboidCollider } from '@react-three/rapier'
import * as THREE from 'three'
import { COLORS } from '@shared/constants'

const COOLDOWN = 1.2
const lastTrigger = new Map<number, number>()

interface TeleporterProps {
  position: [number, number, number]
  exit: [number, number, number]
  rotationY?: number
}

export default function Teleporter({ position, exit, rotationY = 0 }: TeleporterProps) {
  return (
    <group position={position} rotation={[0, rotationY, 0]}>
      <RigidBody
        type="fixed"
        colliders={false}
        onIntersectionEnter={({ other }) => {
          const body = other.rigidBody
          if (!body) return
          const now = performance.now() / 1000
          const last = lastTrigger.get(body.handle) ?? -Infinity
          if (now - last < COOLDOWN) return
          lastTrigger.set(body.handle, now)
          body.setTranslation(
            { x: exit[0], y: exit[1], z: exit[2] },
            true,
          )
          const vel = body.linvel()
          body.setLinvel({ x: vel.x, y: 0, z: vel.z }, true)
        }}
      >
        <CuboidCollider args={[1.1, 1.7, 0.2]} position={[0, 1.7, 0]} sensor />
      </RigidBody>

      <mesh position={[0, 1.7, 0]}>
        <planeGeometry args={[2.2, 3.4]} />
        <meshStandardMaterial
          color={COLORS.teleporter}
          emissive={COLORS.teleporter}
          emissiveIntensity={0.85}
          transparent
          opacity={0.5}
          side={THREE.DoubleSide}
        />
      </mesh>

      <mesh position={[-1.15, 1.7, 0]}>
        <boxGeometry args={[0.12, 3.5, 0.12]} />
        <meshStandardMaterial color="#23262b" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[1.15, 1.7, 0]}>
        <boxGeometry args={[0.12, 3.5, 0.12]} />
        <meshStandardMaterial color="#23262b" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[0, 3.45, 0]}>
        <boxGeometry args={[2.42, 0.14, 0.14]} />
        <meshStandardMaterial color="#23262b" metalness={0.6} roughness={0.4} />
      </mesh>
      <mesh position={[0, 0.06, 0]}>
        <boxGeometry args={[2.2, 0.12, 0.12]} />
        <meshStandardMaterial
          color={COLORS.teleporter}
          emissive={COLORS.teleporter}
          emissiveIntensity={0.9}
        />
      </mesh>
    </group>
  )
}