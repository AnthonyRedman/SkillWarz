import { useGame } from '../../store/gameStore'
import { COLORS } from '@shared/constants'

export default function Lighting() {
  const night = useGame((s) => s.night)

  return (
    <>
      <ambientLight intensity={night ? 0.12 : 0.45} />
      <directionalLight
        castShadow
        position={[25, 35, 20]}
        color={night ? '#8fa8c8' : '#ffffff'}
        intensity={night ? 0.35 : 1.4}
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-55}
        shadow-camera-right={55}
        shadow-camera-top={30}
        shadow-camera-bottom={-30}
        shadow-camera-near={1}
        shadow-camera-far={100}
      />
      <hemisphereLight
        args={[night ? '#1a2233' : '#bfd9ff', night ? '#00030a' : '#2c3d52', night ? 0.25 : 0.4]}
      />
      <color attach="background" args={[night ? '#0b0e14' : COLORS.floor]} />
    </>
  )
}