import { RigidBody, CuboidCollider } from '@react-three/rapier'
import { ARENA_STATIC_BOXES } from '@shared/map'
import { ARENA, COLORS } from '@shared/constants'
import BouncePad from './BouncePad'
import Teleporter from './Teleporter'

const { sizeX, sizeZ, wallHeight } = ARENA

function StaticBoxes() {
  return (
    <>
      {ARENA_STATIC_BOXES.map((def, i) => (
        <RigidBody
          key={i}
          type="fixed"
          position={def.position}
          quaternion={def.quaternion}
        >
          <mesh receiveShadow={def.receiveShadow} castShadow={def.castShadow}>
            <boxGeometry args={def.size} />
            <meshStandardMaterial color={def.color} roughness={def.roughness ?? 0.7} />
          </mesh>
          <CuboidCollider args={def.halfExtents} />
        </RigidBody>
      ))}
    </>
  )
}

function Trim() {
  const halfX = sizeX / 2
  const halfZ = sizeZ / 2
  const y = wallHeight - 0.25
  const strips: {
    position: [number, number, number]
    args: [number, number, number]
  }[] = [
    { position: [0, y, -halfZ], args: [sizeX, 0.3, 0.15] },
    { position: [0, y, halfZ], args: [sizeX, 0.3, 0.15] },
    { position: [-halfX, y, 0], args: [0.15, 0.3, sizeZ] },
    { position: [halfX, y, 0], args: [0.15, 0.3, sizeZ] },
  ]

  return (
    <>
      {strips.map((strip, i) => (
        <mesh key={i} position={strip.position}>
          <boxGeometry args={strip.args} />
          <meshStandardMaterial
            color={COLORS.accent}
            emissive={COLORS.accent}
            emissiveIntensity={0.6}
          />
        </mesh>
      ))}
    </>
  )
}

function PlatformTop() {
  return (
    <mesh position={[0, ARENA.platformHeight + 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[ARENA.platformSize, ARENA.platformSize]} />
      <meshStandardMaterial color={COLORS.wall} roughness={0.6} />
    </mesh>
  )
}

function FloorMarkers() {
  const markers: {
    position: [number, number, number]
    args: [number, number, number]
  }[] = [
    { position: [20, 0.02, 0], args: [0.15, 0.04, sizeZ] },
    { position: [-20, 0.02, 0], args: [0.15, 0.04, sizeZ] },
    { position: [0, 0.02, -16], args: [sizeX / 2, 0.04, 0.15] },
    { position: [0, 0.02, 16], args: [sizeX / 2, 0.04, 0.15] },
  ]
  return (
    <>
      {markers.map((m, i) => (
        <mesh key={i} position={m.position}>
          <boxGeometry args={m.args} />
          <meshStandardMaterial
            color="#3a4a5e"
            emissive={COLORS.accent}
            emissiveIntensity={0.25}
          />
        </mesh>
      ))}
    </>
  )
}

export default function Arena() {
  return (
    <>
      <StaticBoxes />
      <PlatformTop />
      <Trim />
      <FloorMarkers />
      <BouncePad position={[12, 0.15, 8]} />
      <BouncePad position={[-12, 0.15, -8]} />
      <BouncePad position={[0, 0.15, 18]} width={2} depth={2} />
      <Teleporter
        position={[-16, 0, 21.45]}
        exit={[16, 1.2, -19]}
        rotationY={Math.PI}
      />
      <Teleporter
        position={[16, 0, -21.45]}
        exit={[-16, 1.2, 19]}
      />
      <Teleporter
        position={[16, 0, 21.45]}
        exit={[-16, 1.2, -19]}
        rotationY={Math.PI}
      />
      <Teleporter
        position={[-16, 0, -21.45]}
        exit={[16, 1.2, 19]}
      />
    </>
  )
}