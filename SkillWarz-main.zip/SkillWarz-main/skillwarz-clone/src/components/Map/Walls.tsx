export default function Walls() {
  return null
}