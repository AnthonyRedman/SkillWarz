import { RigidBody, CuboidCollider } from '@react-three/rapier'
import { COLORS, MOVEMENT } from '@shared/constants'
import { playerRigidBody } from '../../utils/playerSystem'

const COOLDOWN = 1.2
const lastTrigger = new Map<number, number>()

interface BouncePadProps {
  position: [number, number, number]
  width?: number
  depth?: number
}

export default function BouncePad({ position, width = 3, depth = 3 }: BouncePadProps) {
  return (
    <group position={position}>
      <RigidBody
        type="fixed"
        colliders={false}
        onIntersectionEnter={({ other }) => {
          const body = other.rigidBody
          if (!body) return
          if (body !== playerRigidBody.current) return
          const now = performance.now() / 1000
          const last = lastTrigger.get(body.handle) ?? -Infinity
          if (now - last < COOLDOWN) return
          lastTrigger.set(body.handle, now)
          const vel = body.linvel()
          body.setLinvel(
            { x: vel.x, y: MOVEMENT.bouncePadVelocity, z: vel.z },
            true,
          )
        }}
      >
        <mesh receiveShadow>
          <boxGeometry args={[width, 0.25, depth]} />
          <meshStandardMaterial
            color={COLORS.bouncePad}
            emissive={COLORS.bouncePad}
            emissiveIntensity={0.8}
            roughness={0.4}
          />
        </mesh>
        <CuboidCollider args={[width / 2, 0.125, depth / 2]} position={[0, 0.2, 0]} sensor />
      </RigidBody>
    </group>
  )
}
