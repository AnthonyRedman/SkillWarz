import { KeyboardControls } from '@react-three/drei'
import type { ReactNode } from 'react'
import { keymap } from '../../utils/controls'

export default function PlayerControls({ children }: { children: ReactNode }) {
  return <KeyboardControls map={keymap}>{children}</KeyboardControls>
}