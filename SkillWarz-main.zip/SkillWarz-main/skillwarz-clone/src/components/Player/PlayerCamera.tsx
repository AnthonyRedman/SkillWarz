import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { clampDelta } from '@shared/timestep'
import { CAMERA } from '@shared/constants'
import { clamp } from '../../utils/math'
import { useGame } from '../../store/gameStore'
import { playerRigidBody } from '../../utils/playerSystem'

const PITCH_LIMIT = Math.PI / 2 - 0.01

export default function PlayerCamera() {
  const camera = useThree((state) => state.camera)
  const gl = useThree((state) => state.gl)

  const yaw = useRef(0)
  const pitch = useRef(0)
  const locked = useRef(false)

  useEffect(() => {
    const dom = gl.domElement

    const onLockChange = () => {
      const nowLocked = document.pointerLockElement === dom
      locked.current = nowLocked
      const state = useGame.getState()
      if (!nowLocked && state.started && !state.paused) {
        state.pause()
      } else if (nowLocked && state.started && state.paused) {
        state.resume()
      }
    }
    const onClick = () => {
      if (document.pointerLockElement !== dom) {
        dom.requestPointerLock()
      }
    }
    const onMouseMove = (event: MouseEvent) => {
      if (!locked.current) return
      yaw.current -= event.movementX * CAMERA.sensitivity
      pitch.current = clamp(
        pitch.current - event.movementY * CAMERA.sensitivity,
        -PITCH_LIMIT,
        PITCH_LIMIT,
      )
    }

    document.addEventListener('pointerlockchange', onLockChange)
    dom.addEventListener('click', onClick)
    document.addEventListener('mousemove', onMouseMove)
    return () => {
      document.removeEventListener('pointerlockchange', onLockChange)
      dom.removeEventListener('click', onClick)
      document.removeEventListener('mousemove', onMouseMove)
    }
  }, [gl])

  const euler = useRef(new THREE.Euler(0, 0, 0, 'YXZ'))
  const rightVec = useRef(new THREE.Vector3(1, 0, 0))
  const bobPhase = useRef(0)
  const bobAmp = useRef(0)
  const bobSpeed = useRef(0)

  useFrame((_, rawDelta) => {
    const dt = clampDelta(rawDelta)
    euler.current.set(pitch.current, yaw.current, 0, 'YXZ')
    camera.quaternion.setFromEuler(euler.current)

    const state = useGame.getState()
    const body = playerRigidBody.current
    let bearing = 0
    if (body) {
      const vel = body.linvel()
      bearing = Math.hypot(vel.x, vel.z)
    }
    const moving = state.started && !state.paused && bearing > 0.5
    bobAmp.current = moving
      ? THREE.MathUtils.damp(bobAmp.current, 1, 8, dt)
      : THREE.MathUtils.damp(bobAmp.current, 0, 10, dt)
    bobSpeed.current = THREE.MathUtils.damp(bobSpeed.current, bearing, 8, dt)

    if (moving) {
      bobPhase.current += bobSpeed.current * dt * CAMERA.bobFrequency
    }

    const amp = CAMERA.bobAmplitude * bobAmp.current
    rightVec.current.set(1, 0, 0).applyQuaternion(camera.quaternion)
    const v = Math.sin(bobPhase.current)
    const s = Math.sin(bobPhase.current * 0.5)
    camera.position.addScaledVector(rightVec.current, amp * 0.3 * s)
    camera.position.y += amp * v
  })

  return null
}