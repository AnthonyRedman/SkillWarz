import { useEffect, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { CapsuleCollider, RigidBody, useRapier, type RapierRigidBody } from '@react-three/rapier'
import type { Collider } from '@dimforge/rapier3d-compat'
import { useKeyboardControls } from '@react-three/drei'
import * as THREE from 'three'
import { CAMERA, MOVEMENT, PLAYER } from '@shared/constants'
import { HUMAN_SPAWNS } from '@shared/spawn'
import { clampDelta, FIXED_TIMESTEP } from '@shared/timestep'
import type { ControlName } from '../../utils/controls'
import { useGame } from '../../store/gameStore'
import { combat } from '../../utils/combat'
import { audio } from '../../utils/audio'
import { playerRigidBody } from '../../utils/playerSystem'

const HALF_HEIGHT = (PLAYER.capsuleHeight - PLAYER.radius * 2) / 2
const EYE_OFFSET = CAMERA.eyeHeight - PLAYER.capsuleHeight / 2
const CROUCH_EYE_OFFSET = EYE_OFFSET - 0.35
const GROUND_RAY = HALF_HEIGHT + PLAYER.radius + 0.1
const GROUND_TOLERANCE = 0.05
const SLIDE_JUMP_BOOST = 1.15

export default function Player() {
  const bodyRef = useRef<RapierRigidBody>(null)
  const colliderRef = useRef<Collider>(null)
  const camera = useThree((state) => state.camera)
  const { world, rapier } = useRapier()
  const [, getControls] = useKeyboardControls<ControlName>()

  const spawn = [...HUMAN_SPAWNS[0]] as [number, number, number]

  useEffect(() => {
    const offMarker = combat.onHitMarker(() => {
      audio.hit()
    })
    return () => {
      offMarker()
    }
  }, [])

  const viewDir = useRef(new THREE.Vector3())
  const forward = useRef(new THREE.Vector3())
  const right = useRef(new THREE.Vector3())
  const direction = useRef(new THREE.Vector3())
  const slideDir = useRef(new THREE.Vector3())
  const isSliding = useRef(false)
  const slideTimer = useRef(0)
  const stepTimer = useRef(0)

  const isGrounded = (body: RapierRigidBody): boolean => {
    const position = body.translation()
    const ray = new rapier.Ray(
      { x: position.x, y: position.y, z: position.z },
      { x: 0, y: -1, z: 0 },
    )
    const hit = world.castRay(
      ray,
      GROUND_RAY,
      false,
      undefined,
      undefined,
      undefined,
      body,
    )
    return hit !== null && hit.timeOfImpact <= HALF_HEIGHT + PLAYER.radius + GROUND_TOLERANCE
  }

  useFrame((_, rawDelta) => {
    const body = bodyRef.current
    if (!body) return
    const dt = clampDelta(rawDelta)
    const state = useGame.getState()

    const position = body.translation()
    playerRigidBody.current = body

    if (!(state.started && !state.paused) || state.dead) {
      const eyeOff = isSliding.current ? CROUCH_EYE_OFFSET : EYE_OFFSET
      camera.position.set(position.x, position.y + eyeOff, position.z)
      return
    }

    const { forward: fwd, backward, left, right: strafeRight, jump, sprint, crouch } = getControls()

    camera.getWorldDirection(viewDir.current)
    const horizontal = Math.hypot(viewDir.current.x, viewDir.current.z)
    if (horizontal > 1e-5) {
      forward.current.set(
        viewDir.current.x / horizontal,
        0,
        viewDir.current.z / horizontal,
      )
    } else {
      forward.current.set(0, 0, -1)
    }
    right.current.set(-forward.current.z, 0, forward.current.x)

    direction.current
      .set(0, 0, 0)
      .addScaledVector(forward.current, (fwd ? 1 : 0) - (backward ? 1 : 0))
      .addScaledVector(right.current, (strafeRight ? 1 : 0) - (left ? 1 : 0))
    const hasInput = direction.current.lengthSq() > 0
    if (hasInput) {
      direction.current.normalize()
    }

    const velocity = body.linvel()
    const grounded = isGrounded(body)

    if (isSliding.current) {
      slideTimer.current -= FIXED_TIMESTEP
      if (!grounded || slideTimer.current <= 0) {
        isSliding.current = false
      }
    }

    if (!isSliding.current && sprint && crouch && grounded && hasInput) {
      isSliding.current = true
      slideTimer.current = MOVEMENT.slideDuration
      slideDir.current.copy(direction.current)
    }

    let targetX: number
    let targetZ: number

    if (isSliding.current) {
      const decay = Math.max(0, slideTimer.current / MOVEMENT.slideDuration)
      const spd = MOVEMENT.slideSpeed * (0.4 + 0.6 * decay)
      targetX = slideDir.current.x * spd
      targetZ = slideDir.current.z * spd
      if (jump) {
        isSliding.current = false
        const boost = SLIDE_JUMP_BOOST
        targetX = slideDir.current.x * spd * boost
        targetZ = slideDir.current.z * spd * boost
        body.setLinvel(
          { x: targetX, y: MOVEMENT.jumpVelocity * 1.08, z: targetZ },
          true,
        )
        const pos = body.translation()
        playerRigidBody.current = body
        camera.position.set(pos.x, pos.y + EYE_OFFSET, pos.z)
        return
      }
    } else if (!grounded) {
      targetX = velocity.x + (direction.current.x * MOVEMENT.sprintSpeed - velocity.x) * MOVEMENT.airControl
      targetZ = velocity.z + (direction.current.z * MOVEMENT.sprintSpeed - velocity.z) * MOVEMENT.airControl
    } else {
      const speed = sprint ? MOVEMENT.sprintSpeed : MOVEMENT.walkSpeed
      targetX = direction.current.x * speed
      targetZ = direction.current.z * speed
    }

    body.setLinvel({ x: targetX, y: velocity.y, z: targetZ }, true)

    if (jump && grounded && !isSliding.current) {
      body.setLinvel({ x: targetX, y: MOVEMENT.jumpVelocity, z: targetZ }, true)
    }

    const eyeOff = isSliding.current ? CROUCH_EYE_OFFSET : EYE_OFFSET
    camera.position.set(position.x, position.y + eyeOff, position.z)

    {
      const hSpeed = Math.hypot(velocity.x, velocity.z)
      if (grounded && hSpeed > 0.5 && !isSliding.current) {
        stepTimer.current -= dt
        const stepInterval = sprint ? 0.31 : 0.48
        if (stepTimer.current <= 0) {
          stepTimer.current = stepInterval
          audio.footstep(sprint)
        }
      } else {
        stepTimer.current = 0.2
      }
    }
  })

  return (
    <RigidBody
      ref={bodyRef}
      position={spawn}
      type="dynamic"
      colliders={false}
      mass={PLAYER.mass}
      enabledRotations={[false, false, false]}
      canSleep={false}
      angularDamping={5}
    >
      <CapsuleCollider ref={colliderRef} args={[HALF_HEIGHT, PLAYER.radius]} />
    </RigidBody>
  )
}