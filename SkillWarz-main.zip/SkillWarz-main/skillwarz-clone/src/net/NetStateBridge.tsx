import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useNet } from '../net/netStore'
import { isConnected } from '../net/network'
import { useGame } from '../store/gameStore'
import { emitPlayerHit } from '../utils/combat'
import { audio } from '../utils/audio'
import { playerRigidBody } from '../utils/playerSystem'
import { WEAPONS } from '@shared/weapons'

export default function NetStateBridge() {
  const prev = useRef({ health: 100, dead: false })

  useFrame(() => {
    if (!isConnected()) return
    const { selfId, players } = useNet.getState()
    if (!selfId) return
    const p = players[selfId]
    if (!p) return
    const before = prev.current

    if (p.health < before.health && p.health > 0) {
      emitPlayerHit(before.health - p.health)
      audio.hurt()
    }

    const dead = p.health <= 0
    if (dead && !before.dead) {
      audio.death()
      useGame.getState().setDead(true)
    } else if (!dead && before.dead) {
      useGame.getState().setDead(false)
      const def = WEAPONS[useGame.getState().weapon]
      useGame.getState().setAmmo(def.ammoCapacity, def.ammoCapacity)
      playerRigidBody.current?.setTranslation({ x: p.x, y: p.y, z: p.z }, true)
      playerRigidBody.current?.setLinvel({ x: 0, y: 0, z: 0 }, true)
      playerRigidBody.current?.setAngvel({ x: 0, y: 0, z: 0 }, true)
    }

    useGame.getState().syncCombat({
      health: p.health,
      maxHealth: p.maxHealth,
      score: p.score,
      kills: p.kills,
      deaths: p.deaths,
      isBot: p.isBot,
    })
    prev.current = { health: p.health, dead }
  })

  return null
}