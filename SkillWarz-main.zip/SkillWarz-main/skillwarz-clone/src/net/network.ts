import { Client, type Room } from '@colyseus/sdk'
import {
  ROOM_NAME,
  type JoinOptions,
  type KillFeedMessage,
  type NetState,
  type PlayerInputMessage,
  type ShootMessage,
} from '@shared/network'
import { useNet } from './netStore'
import { useAuth } from '../store/authStore'

const WS_URL: string = (import.meta.env.VITE_WS_URL as string | undefined) ?? 'ws://localhost:2567'

let client: Client | null = null
let room: Room<NetState> | null = null

function displayName(): string {
  return `Host-${Math.random().toString(16).slice(2, 6)}`
}

export function isConnected(): boolean {
  return room !== null
}

export async function connectNet(difficulty = 'normal'): Promise<void> {
  if (room) return
  useNet.getState().setStatus('connecting')
  try {
    client ??= new Client(WS_URL)
    const { token, user } = useAuth.getState()
    const options: JoinOptions = {
      name: user?.username ?? displayName(),
      difficulty,
      authToken: token ?? undefined,
    }
    const joined = await client.joinOrCreate<NetState>(ROOM_NAME, options)
    useNet.getState().setStatus('online')
    room = joined
    useNet.getState().setSelfId(joined.sessionId)
    joined.onStateChange((state) => useNet.getState().applyState(state))
    joined.onMessage('killfeed', (message: KillFeedMessage) => {
      useNet.getState().pushKillFeed(message)
    })
    joined.onError((_code, message) => console.error('[net] room error:', message))
    joined.onLeave(() => {
      room = null
      useNet.getState().setSelfId(null)
      useNet.getState().clearPlayers()
      useNet.getState().setStatus('offline')
    })
  } catch (err) {
    console.error('[net] failed to connect to', WS_URL, err)
    room = null
    useNet.getState().setStatus('offline')
  }
}

export function sendInput(message: PlayerInputMessage): void {
  room?.send('input', message)
}

export function sendShoot(message: ShootMessage): void {
  room?.send('shoot', message)
}

if (import.meta.env.DEV) {
  ;(window as unknown as Record<string, unknown>).__skillwarzNet = useNet
  ;(window as unknown as Record<string, unknown>).__skillwarzSend = {
    input: sendInput,
    shoot: sendShoot,
  }
}