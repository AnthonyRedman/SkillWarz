import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import { useNet, type NetPlayer } from '../net/netStore'

function lerpAngle(a: number, b: number, t: number): number {
  const diff = ((b - a + Math.PI * 3) % (Math.PI * 2)) - Math.PI
  return a + diff * t
}

function RemotePlayer({ player }: { player: NetPlayer }) {
  const group = useRef<THREE.Group>(null)
  const yawRef = useRef(player.yaw)

  useFrame((_, rawDelta) => {
    const g = group.current
    if (!g) return
    const dt = Math.min(rawDelta, 0.1)
    const k = 1 - Math.pow(0.0001, dt)
    g.position.x += (player.x - g.position.x) * k
    g.position.y += (player.y + 0.9 - g.position.y) * k
    g.position.z += (player.z - g.position.z) * k
    yawRef.current = lerpAngle(yawRef.current, player.yaw, k)
    g.rotation.y = yawRef.current
  })

  const hp = Math.max(0, Math.min(1, player.health / 100))

  return (
    <group ref={group}>
      <mesh castShadow>
        <capsuleGeometry args={[0.4, 1, 5, 12]} />
        <meshStandardMaterial color={player.isBot ? '#d34f6a' : '#4f7ddc'} />
      </mesh>
      <group position={[0, 1.95, 0]}>
        <mesh position={[0, 0, 0]}>
          <planeGeometry args={[1, 0.14]} />
          <meshBasicMaterial color="#1c2733" depthTest={false} transparent opacity={0.8} />
        </mesh>
        <mesh position={[-0.47 * (1 - hp), 0, 0.002]}>
          <planeGeometry args={[0.94 * hp || 0.001, 0.1]} />
          <meshBasicMaterial color="#43d17c" depthTest={false} />
        </mesh>
      </group>
      <Html position={[0, 2.45, 0]} center distanceFactor={10} style={{ pointerEvents: 'none' }}>
        <div className="net-name">{player.name}</div>
      </Html>
    </group>
  )
}

export default function RemotePlayers() {
  const selfId = useNet((s) => s.selfId)
  const players = useNet((s) => s.players)

  return (
    <>
      {Object.entries(players)
        .filter(([id]) => id !== selfId)
        .map(([id, player]) => (
          <RemotePlayer key={id} player={player} />
        ))}
    </>
  )
}