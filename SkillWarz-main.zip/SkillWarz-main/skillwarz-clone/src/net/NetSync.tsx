import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { useKeyboardControls } from '@react-three/drei'
import * as THREE from 'three'
import { playerRigidBody } from '../utils/playerSystem'
import type { ControlName } from '../utils/controls'
import { isConnected, sendInput } from './network'
import { useNet } from './netStore'

const SNAP_RADIUS = 4
const BLEND_RADIUS = 0.4
const BLEND_RATE = 0.28

export default function NetSync() {
  const camera = useThree((state) => state.camera)
  const [, getControls] = useKeyboardControls<ControlName>()
  const tmp = useRef(new THREE.Vector3())

  useFrame(() => {
    if (!isConnected()) return

    const q = camera.quaternion
    const yaw = Math.atan2(2 * (q.w * q.y + q.x * q.z), 1 - 2 * (q.y * q.y + q.z * q.z))
    const c = getControls()
    sendInput({
      yaw,
      forward: c.forward,
      backward: c.backward,
      left: c.left,
      right: c.right,
      jump: c.jump,
      sprint: c.sprint,
      crouch: c.crouch,
    })

    const selfId = useNet.getState().selfId
    if (!selfId) return
    const server = useNet.getState().players[selfId]
    if (!server) return
    const body = playerRigidBody.current
    if (!body) return

    const pos = body.translation()
    tmp.current.set(pos.x, pos.y, pos.z)
    const dx = server.x - pos.x
    const dy = server.y - pos.y
    const dz = server.z - pos.z
    const dist = Math.hypot(dx, dy, dz)

    if (dist > SNAP_RADIUS) {
      body.setTranslation({ x: server.x, y: server.y, z: server.z }, true)
    } else if (dist > BLEND_RADIUS) {
      body.setTranslation(
        {
          x: pos.x + dx * BLEND_RATE,
          y: pos.y + dy * BLEND_RATE,
          z: pos.z + dz * BLEND_RATE,
        },
        true,
      )
    }
  })

  return null
}