import { create } from 'zustand'
import type { KillFeedMessage, NetPlayerData, NetState } from '@shared/network'
import { useGame } from '../store/gameStore'

export type NetStatus = 'idle' | 'connecting' | 'online' | 'offline'

export interface NetPlayer {
  id: string
  name: string
  x: number
  y: number
  z: number
  yaw: number
  health: number
  maxHealth: number
  score: number
  kills: number
  deaths: number
  isBot: boolean
}

type NetStore = {
  status: NetStatus
  selfId: string | null
  players: Record<string, NetPlayer>
  setStatus: (status: NetStatus) => void
  setSelfId: (id: string | null) => void
  applyState: (state: NetState) => void
  clearPlayers: () => void
  pushKillFeed: (message: KillFeedMessage) => void
}

export const useNet = create<NetStore>((set, get) => ({
  status: 'idle',
  selfId: null,
  players: {},
  setStatus: (status) => set({ status }),
  setSelfId: (selfId) => set({ selfId }),
  applyState: (state) => {
    const players: Record<string, NetPlayer> = {}
    state.players.forEach((value: NetPlayerData, key: string) => {
      players[key] = { id: key, ...value }
    })
    set({ players })
  },
  clearPlayers: () => set({ players: {} }),
  pushKillFeed: (message) => {
    const selfId = get().selfId
    const lines = `${message.killer} killed ${message.victim}`
    useGame.getState().pushKillFeed({
      text: lines,
      kind: message.victim === selfId ? 'death' : 'kill',
    })
  },
}))