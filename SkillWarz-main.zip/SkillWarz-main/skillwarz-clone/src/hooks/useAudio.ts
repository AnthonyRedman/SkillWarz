export function useAudio() {
  return {}
}