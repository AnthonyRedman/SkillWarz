import { useCallback, useEffect, useRef } from 'react'
import { useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { useGame } from '../store/gameStore'
import { combat } from '../utils/combat'
import { audio } from '../utils/audio'
import { spawnBulletFromCamera, spreadDirection } from '../utils/projectiles'
import type { WeaponDef } from '@shared/weapons'
import { sendShoot } from '../net/network'

export function useWeapon(def: WeaponDef) {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera

  const defRef = useRef(def)
  const cameraRef = useRef(camera)
  useEffect(() => {
    defRef.current = def
    cameraRef.current = camera
  })

  const cooldown = useRef(0)
  const reloading = useRef(false)
  const reloadTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (reloadTimer.current) {
      clearTimeout(reloadTimer.current)
      reloadTimer.current = null
    }
    reloading.current = false
    cooldown.current = 0
    useGame.getState().setAmmo(def.ammoCapacity, def.ammoCapacity)
    return () => {
      if (reloadTimer.current) {
        clearTimeout(reloadTimer.current)
        reloadTimer.current = null
      }
      useGame.getState().setAmmo(def.ammoCapacity, def.ammoCapacity)
    }
  }, [def])

  const startReload = useCallback(() => {
    if (reloading.current) return
    const state = useGame.getState()
    if (state.ammo === state.maxAmmo) return
    reloading.current = true
    const { ammoCapacity, reloadTime } = defRef.current
    audio.reload()
    reloadTimer.current = setTimeout(() => {
      useGame.getState().setAmmo(ammoCapacity, ammoCapacity)
      reloading.current = false
      reloadTimer.current = null
    }, reloadTime * 1000)
  }, [])

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code !== 'KeyR') return
      const state = useGame.getState()
      if (!state.started || state.paused) return
      startReload()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [startReload])

  const fire = useCallback(() => {
    if (cooldown.current > 0 || reloading.current) return

    const state = useGame.getState()
    if (state.ammo <= 0) {
      startReload()
      return
    }

    spawnBulletFromCamera(cameraRef.current, defRef.current)
    const cam = cameraRef.current
    const baseDir = new THREE.Vector3()
    cam.getWorldDirection(baseDir)
    const dir = spreadDirection(baseDir, defRef.current.spread)
    sendShoot({
      weapon: defRef.current.name,
      ox: cam.position.x,
      oy: cam.position.y,
      oz: cam.position.z,
      dx: dir.x,
      dy: dir.y,
      dz: dir.z,
    })
    audio.gunshot(defRef.current.name)
    combat.emitShot()
    state.consumeAmmo(1)
    cooldown.current = 1 / defRef.current.fireRate
  }, [startReload])

  return {
    fire,
    startReload,
    get ammo() {
      return useGame.getState().ammo
    },
    get isReloading() {
      return reloading.current
    },
    setCooldown: (dt: number) => {
      if (cooldown.current > 0) cooldown.current -= dt
    },
  }
}