export type WeaponName = 'pistol' | 'rifle' | 'shotgun'

export interface GunShape {
  bodyW: number
  bodyH: number
  bodyL: number
  barrelW: number
  barrelH: number
  barrelL: number
  stock: number
  magH: number
}

export interface WeaponDef {
  name: WeaponName
  label: string
  damage: number
  fireRate: number
  ammoCapacity: number
  spread: number
  pellets: number
  reloadTime: number
  recoil: number
  bulletSpeed: number
  color: string
  accent: string
  holdX: number
  holdY: number
  holdZ: number
  shape: GunShape
}

export const WEAPONS: Record<WeaponName, WeaponDef> = {
  pistol: {
    name: 'pistol',
    label: 'Pistol',
    damage: 34,
    fireRate: 3.5,
    ammoCapacity: 12,
    spread: 0.004,
    pellets: 1,
    reloadTime: 1.1,
    recoil: 0.1,
    bulletSpeed: 300,
    color: '#2b2d31',
    accent: '#4a9eff',
    holdX: 0.32,
    holdY: -0.3,
    holdZ: -0.62,
    shape: {
      bodyW: 0.09,
      bodyH: 0.11,
      bodyL: 0.42,
      barrelW: 0.05,
      barrelH: 0.05,
      barrelL: 0.22,
      stock: 0,
      magH: 0.15,
    },
  },
  rifle: {
    name: 'rifle',
    label: 'Rifle',
    damage: 22,
    fireRate: 9,
    ammoCapacity: 30,
    spread: 0.014,
    pellets: 1,
    reloadTime: 1.8,
    recoil: 0.07,
    bulletSpeed: 320,
    color: '#26292e',
    accent: '#e0b545',
    holdX: 0.3,
    holdY: -0.29,
    holdZ: -0.72,
    shape: {
      bodyW: 0.08,
      bodyH: 0.1,
      bodyL: 0.5,
      barrelW: 0.04,
      barrelH: 0.04,
      barrelL: 0.42,
      stock: 0.2,
      magH: 0.16,
    },
  },
  shotgun: {
    name: 'shotgun',
    label: 'Shotgun',
    damage: 11,
    fireRate: 1.3,
    ammoCapacity: 6,
    spread: 0.05,
    pellets: 6,
    reloadTime: 2.2,
    recoil: 0.2,
    bulletSpeed: 250,
    color: '#3a301f',
    accent: '#e05252',
    holdX: 0.3,
    holdY: -0.31,
    holdZ: -0.68,
    shape: {
      bodyW: 0.1,
      bodyH: 0.14,
      bodyL: 0.4,
      barrelW: 0.07,
      barrelH: 0.07,
      barrelL: 0.5,
      stock: 0.28,
      magH: 0,
    },
  },
}

export const FIRE_RANGE = 100

export const BOT_WEAPON: WeaponDef = {
  name: 'pistol',
  label: 'Bot Pistol',
  damage: 11,
  fireRate: 1.6,
  ammoCapacity: 0,
  spread: 0.055,
  pellets: 1,
  reloadTime: 0,
  recoil: 0,
  bulletSpeed: 260,
  color: '#2b2d31',
  accent: '#ff6b4a',
  holdX: 0,
  holdY: 0,
  holdZ: 0,
  shape: {
    bodyW: 0.09,
    bodyH: 0.11,
    bodyL: 0.42,
    barrelW: 0.05,
    barrelH: 0.05,
    barrelL: 0.22,
    stock: 0,
    magH: 0,
  },
}