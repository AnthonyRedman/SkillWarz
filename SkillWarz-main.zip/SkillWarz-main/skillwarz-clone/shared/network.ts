import type { WeaponName } from './weapons'

export const ROOM_NAME = 'deathmatch'
export const MAX_PLAYERS = 8

export interface NetPlayerData {
  name: string
  x: number
  y: number
  z: number
  yaw: number
  health: number
  maxHealth: number
  score: number
  kills: number
  deaths: number
  isBot: boolean
}

export interface PlayerInputMessage {
  yaw: number
  forward: boolean
  backward: boolean
  left: boolean
  right: boolean
  jump: boolean
  sprint: boolean
  crouch: boolean
}

export interface ShootMessage {
  weapon: WeaponName
  ox: number
  oy: number
  oz: number
  dx: number
  dy: number
  dz: number
}

export interface KillFeedMessage {
  killer: string
  victim: string
  killerIsBot: boolean
  victimIsBot: boolean
  weapon: WeaponName | 'bot'
}

export interface JoinOptions {
  name?: string
  difficulty?: string
  authToken?: string
}

export interface NetState {
  players: {
    forEach: (callback: (value: NetPlayerData, key: string) => void) => void
  }
}