import * as THREE from 'three'
import { ARENA, COLORS } from './constants.ts'
import type * as RAPIER from '@dimforge/rapier3d-compat'

const { sizeX, sizeZ, wallHeight, platformSize, platformHeight, rampRun, rampRise, rampWidth } =
  ARENA

const halfX = sizeX / 2
const halfZ = sizeZ / 2
const wallThickness = 1

export interface BoxColliderDef {
  position: [number, number, number]
  size: [number, number, number]
  halfExtents: [number, number, number]
  quaternion?: [number, number, number, number]
  color: string
  roughness?: number
  receiveShadow?: boolean
  castShadow?: boolean
}

function box(
  position: [number, number, number],
  size: [number, number, number],
  color: string,
  options: Partial<BoxColliderDef> = {},
): BoxColliderDef {
  return {
    position,
    size,
    halfExtents: [size[0] / 2, size[1] / 2, size[2] / 2],
    color,
    ...options,
  }
}

function rampQuaternion(dir: readonly [number, number]): [number, number, number, number] {
  const tilt = -Math.atan2(rampRise, rampRun)
  const yaw = Math.atan2(dir[0], dir[1])
  const yAxis = new THREE.Vector3(0, 1, 0)
  const xAxis = new THREE.Vector3(1, 0, 0)
  const qy = new THREE.Quaternion().setFromAxisAngle(yAxis, yaw)
  const qx = new THREE.Quaternion().setFromAxisAngle(xAxis, tilt)
  qy.multiply(qx)
  return [qy.x, qy.y, qy.z, qy.w]
}

export const ARENA_STATIC_BOXES: BoxColliderDef[] = [
  box([0, -0.5, 0], [sizeX, 1, sizeZ], COLORS.floor, { roughness: 0.9 }),
  box([0, wallHeight / 2, halfZ], [sizeX, wallHeight, wallThickness], COLORS.wall, {
    roughness: 0.8,
    receiveShadow: true,
    castShadow: true,
  }),
  box([0, wallHeight / 2, -halfZ], [sizeX, wallHeight, wallThickness], COLORS.wall, {
    roughness: 0.8,
    receiveShadow: true,
    castShadow: true,
  }),
  box([halfX, wallHeight / 2, 0], [wallThickness, wallHeight, sizeZ], COLORS.wall, {
    roughness: 0.8,
    receiveShadow: true,
    castShadow: true,
  }),
  box([-halfX, wallHeight / 2, 0], [wallThickness, wallHeight, sizeZ], COLORS.wall, {
    roughness: 0.8,
    receiveShadow: true,
    castShadow: true,
  }),
  box([0, platformHeight / 2, 0], [platformSize, platformHeight, platformSize], COLORS.ramp, {
    receiveShadow: true,
    castShadow: true,
  }),
]

const rampLength = Math.hypot(rampRun, rampRise)
const rampDefs: { start: readonly [number, number]; dir: readonly [number, number] }[] = [
  { start: [0, -16], dir: [0, 1] },
  { start: [0, 8], dir: [0, 1] },
  { start: [-16, 0], dir: [1, 0] },
  { start: [8, 0], dir: [1, 0] },
]
for (const { start, dir } of rampDefs) {
  const midX = start[0] + (dir[0] * rampRun) / 2
  const midZ = start[1] + (dir[1] * rampRun) / 2
  ARENA_STATIC_BOXES.push(
    box([midX, rampRise / 2, midZ], [rampWidth, 0.4, rampLength], COLORS.ramp, {
      receiveShadow: true,
      castShadow: true,
      quaternion: rampQuaternion(dir),
    }),
  )
}

const crateSpots: { p: readonly [number, number]; s: number }[] = [
  { p: [10, 16], s: 1.5 },
  { p: [-10, 16], s: 1.5 },
  { p: [24, 14], s: 1.8 },
  { p: [-24, 16], s: 2.0 },
  { p: [26, -8], s: 1.2 },
  { p: [-25, -8], s: 1.2 },
  { p: [18, -18], s: 1.5 },
  { p: [-18, -18], s: 1.5 },
]
for (const { p, s } of crateSpots) {
  ARENA_STATIC_BOXES.push(
    box([p[0], s / 2, p[1]], [s, s, s], COLORS.crate, {
      receiveShadow: true,
      castShadow: true,
    }),
  )
}

export interface TriggerDef {
  center: readonly [number, number, number]
  half: readonly [number, number, number]
}

export interface BouncePadDef extends TriggerDef {}

export interface TeleporterDef extends TriggerDef {
  exit: readonly [number, number, number]
}

export const BOUNCE_PADS: BouncePadDef[] = [
  { center: [12, 0.15 + 0.2, 8], half: [1.5, 0.125, 1.5] },
  { center: [-12, 0.15 + 0.2, -8], half: [1.5, 0.125, 1.5] },
  { center: [0, 0.15 + 0.2, 18], half: [1, 0.125, 1] },
]

export const TELEPORTERS: TeleporterDef[] = [
  { center: [-16, 0 + 1.7, 21.45], half: [1.1, 1.7, 1.1], exit: [16, 1.2, -19] },
  { center: [16, 0 + 1.7, -21.45], half: [1.1, 1.7, 1.1], exit: [-16, 1.2, 19] },
  { center: [16, 0 + 1.7, 21.45], half: [1.1, 1.7, 1.1], exit: [-16, 1.2, -19] },
  { center: [-16, 0 + 1.7, -21.45], half: [1.1, 1.7, 1.1], exit: [16, 1.2, 19] },
]

export function addArenaColliders(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  boxes: readonly BoxColliderDef[] = ARENA_STATIC_BOXES,
): void {
  for (const def of boxes) {
    const body = world.createRigidBody(
      RAPIER.RigidBodyDesc.fixed().setTranslation(
        def.position[0],
        def.position[1],
        def.position[2],
      ),
    )
    let colliderDesc = RAPIER.ColliderDesc.cuboid(
      def.halfExtents[0],
      def.halfExtents[1],
      def.halfExtents[2],
    )
    if (def.quaternion) {
      const [x, y, z, w] = def.quaternion
      colliderDesc = colliderDesc.setRotation({ x, y, z, w })
    }
    world.createCollider(colliderDesc, body)
  }
}