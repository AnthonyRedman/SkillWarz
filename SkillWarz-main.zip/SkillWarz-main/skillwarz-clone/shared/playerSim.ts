import { MOVEMENT, PLAYER } from './constants.ts'
import type { PlayerInputMessage } from './network.ts'
import { FIXED_TIMESTEP } from './timestep.ts'
import type * as RAPIER from '@dimforge/rapier3d-compat'

const HALF_HEIGHT = (PLAYER.capsuleHeight - PLAYER.radius * 2) / 2
const GROUND_RAY = HALF_HEIGHT + PLAYER.radius + 0.1
const GROUND_TOLERANCE = 0.05
const SLIDE_JUMP_BOOST = 1.15

export const PLAYER_HALF_HEIGHT = HALF_HEIGHT + PLAYER.radius
export const PLAYER_RADIUS = PLAYER.radius

export interface PlayerMotionState {
  isSliding: boolean
  slideTimer: number
  slideDir: { x: number; z: number }
}

export function createMotionState(): PlayerMotionState {
  return { isSliding: false, slideTimer: 0, slideDir: { x: 0, z: 0 } }
}

export function createPlayerBody(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  spawn: readonly [number, number, number],
  playerId?: string,
): RAPIER.RigidBody {
  const body = world.createRigidBody(
    RAPIER.RigidBodyDesc.dynamic()
      .setTranslation(spawn[0], spawn[1], spawn[2])
      .lockRotations()
      .setCanSleep(false)
      .setAngularDamping(5),
  )
  world.createCollider(
    RAPIER.ColliderDesc.capsule(HALF_HEIGHT, PLAYER.radius).setMass(PLAYER.mass),
    body,
  )
  if (playerId !== undefined) {
    body.userData = { playerId }
  }
  return body
}

function isGrounded(
  world: RAPIER.World,
  body: RAPIER.RigidBody,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
): boolean {
  const position = body.translation()
  const ray = new RAPIER.Ray(
    { x: position.x, y: position.y, z: position.z },
    { x: 0, y: -1, z: 0 },
  )
  const hit = world.castRay(
    ray,
    GROUND_RAY,
    false,
    undefined,
    undefined,
    undefined,
    body,
  )
  return hit !== null && hit.timeOfImpact <= HALF_HEIGHT + PLAYER.radius + GROUND_TOLERANCE
}

export function stepPlayerMotion(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  body: RAPIER.RigidBody,
  motion: PlayerMotionState,
  input: PlayerInputMessage,
  dt: number = FIXED_TIMESTEP,
): void {
  const yaw = input.yaw
  const fx = -Math.sin(yaw)
  const fz = -Math.cos(yaw)
  const rx = -fz
  const rz = fx

  let dx = fx * ((input.forward ? 1 : 0) - (input.backward ? 1 : 0))
  let dz = fz * ((input.forward ? 1 : 0) - (input.backward ? 1 : 0))
  dx += rx * ((input.right ? 1 : 0) - (input.left ? 1 : 0))
  dz += rz * ((input.right ? 1 : 0) - (input.left ? 1 : 0))
  const len = Math.hypot(dx, dz)
  if (len > 0) {
    dx /= len
    dz /= len
  }
  const hasInput = len > 0

  const grounded = isGrounded(world, body, RAPIER)
  const velocity = body.linvel()

  if (motion.isSliding) {
    motion.slideTimer -= dt
    if (!grounded || motion.slideTimer <= 0) {
      motion.isSliding = false
    }
  }

  if (!motion.isSliding && input.sprint && input.crouch && grounded && hasInput) {
    motion.isSliding = true
    motion.slideTimer = MOVEMENT.slideDuration
    motion.slideDir = { x: dx, z: dz }
  }

  let targetX: number
  let targetZ: number

  if (motion.isSliding) {
    const decay = Math.max(0, motion.slideTimer / MOVEMENT.slideDuration)
    const spd = MOVEMENT.slideSpeed * (0.4 + 0.6 * decay)
    targetX = motion.slideDir.x * spd
    targetZ = motion.slideDir.z * spd
    if (input.jump) {
      motion.isSliding = false
      body.setLinvel(
        {
          x: targetX * SLIDE_JUMP_BOOST,
          y: MOVEMENT.jumpVelocity * 1.08,
          z: targetZ * SLIDE_JUMP_BOOST,
        },
        true,
      )
      return
    }
  } else if (!grounded) {
    targetX = velocity.x + (dx * MOVEMENT.sprintSpeed - velocity.x) * MOVEMENT.airControl
    targetZ = velocity.z + (dz * MOVEMENT.sprintSpeed - velocity.z) * MOVEMENT.airControl
  } else {
    const speed = input.sprint ? MOVEMENT.sprintSpeed : MOVEMENT.walkSpeed
    targetX = dx * speed
    targetZ = dz * speed
  }

  body.setLinvel({ x: targetX, y: velocity.y, z: targetZ }, true)

  if (input.jump && grounded && !motion.isSliding) {
    body.setLinvel({ x: targetX, y: MOVEMENT.jumpVelocity, z: targetZ }, true)
  }
}