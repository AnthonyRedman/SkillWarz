import type * as RAPIER from '@dimforge/rapier3d-compat'
import { FIRE_RANGE, WEAPONS, type WeaponName } from './weapons'

export interface HitOrigin {
  x: number
  y: number
  z: number
}

export interface HitDirection {
  x: number
  y: number
  z: number
}

function readPlayerId(collider: RAPIER.Collider): string | null {
  const data = collider.parent()?.userData as { playerId?: string } | null
  return data && typeof data.playerId === 'string' ? data.playerId : null
}

export function resolveShot(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  wep: WeaponName,
  origin: HitOrigin,
  dir: HitDirection,
  shooterBody: RAPIER.RigidBody,
): { victimId: string; damage: number } | null {
  const def = WEAPONS[wep]
  const ray = new RAPIER.Ray(
    { x: origin.x, y: origin.y, z: origin.z },
    { x: dir.x, y: dir.y, z: dir.z },
  )
  const hit = world.castRay(
    ray,
    FIRE_RANGE,
    true,
    undefined,
    undefined,
    undefined,
    shooterBody,
    undefined,
  )
  if (!hit) return null
  const victimId = readPlayerId(hit.collider)
  if (!victimId) return null
  return { victimId, damage: def.damage }
}

export function resolveBotShot(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  eye: HitOrigin,
  dir: HitDirection,
  shooterBody: RAPIER.RigidBody,
  damage: number,
): { victimId: string; damage: number } | null {
  const ray = new RAPIER.Ray(
    { x: eye.x, y: eye.y, z: eye.z },
    { x: dir.x, y: dir.y, z: dir.z },
  )
  const hit = world.castRay(
    ray,
    FIRE_RANGE,
    true,
    undefined,
    undefined,
    undefined,
    shooterBody,
    undefined,
  )
  if (!hit) return null
  const victimId = readPlayerId(hit.collider)
  if (!victimId) return null
  return { victimId, damage }
}