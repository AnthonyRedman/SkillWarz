import { schema, t, type SchemaType } from '@colyseus/schema'

export const PlayerState = schema(
  {
    name: t.string(),
    x: t.float32(),
    y: t.float32(),
    z: t.float32(),
    yaw: t.float32(),
    health: t.uint8(),
    maxHealth: t.uint8(),
    score: t.uint16(),
    kills: t.uint8(),
    deaths: t.uint8(),
    isBot: t.boolean(),
  },
  'PlayerState',
)
export type PlayerState = SchemaType<typeof PlayerState>

export const DeathmatchState = schema(
  {
    players: t.map(PlayerState),
  },
  'DeathmatchState',
)
export type DeathmatchState = SchemaType<typeof DeathmatchState>