export const FIXED_TIMESTEP = 1 / 60

export const MAX_RENDER_DELTA = 1 / 30

export const MAX_FIXED_STEPS_PER_TICK = 5

export function clampDelta(rawDelta: number): number {
  return Math.min(rawDelta, MAX_RENDER_DELTA)
}

export type StepCallback = (fixedDt: number) => void

export interface FixedTimestepAccumulator {
  advance: (rawDelta: number, onStep: StepCallback) => void
  reset: () => void
}

export function createFixedTimestep(fixedDt: number = FIXED_TIMESTEP): FixedTimestepAccumulator {
  let accumulator = 0
  return {
    advance(rawDelta, onStep) {
      accumulator += clampDelta(rawDelta)
      let steps = 0
      while (accumulator >= fixedDt && steps < MAX_FIXED_STEPS_PER_TICK) {
        accumulator -= fixedDt
        onStep(fixedDt)
        steps++
      }
      if (steps >= MAX_FIXED_STEPS_PER_TICK) {
        accumulator = 0
      }
    },
    reset() {
      accumulator = 0
    },
  }
}