export const WORLD = {
  gravity: -20,
  groundSize: 60,
  ceiling: false,
} as const

export const MOVEMENT = {
  walkSpeed: 6,
  sprintSpeed: 9,
  slideSpeed: 13,
  jumpVelocity: 7,
  airControl: 0.25,
  slideDuration: 0.9,
  bouncePadVelocity: 14,
} as const

export const ARENA = {
  sizeX: 80,
  sizeZ: 44,
  wallHeight: 6,
  floorThickness: 1,
  platformSize: 16,
  platformHeight: 2,
  rampRun: 8,
  rampRise: 2,
  rampWidth: 14,
} as const

export const CAMERA = {
  fov: 70,
  near: 0.1,
  far: 200,
  eyeHeight: 1.62,
  sensitivity: 0.0022,
  bobFrequency: 1.8,
  bobAmplitude: 0.06,
} as const

export const PLAYER = {
  radius: 0.4,
  capsuleHeight: 1.8,
  mass: 75,
} as const

export const BOT = {
  maxHealth: 100,
  mass: 75,
  patrolSpeed: 3.2,
  chaseSpeed: 5.2,
  strafeSpeed: 3.6,
  detectionRange: 34,
  shootRange: 21,
  minShootRange: 5,
  jumpVelocity: 6.5,
  jumpUp: 6,
  respawnTime: 3.5,
  eyeHeight: 1.65,
} as const

export const BOT_COUNT = 4

export const BOT_SPAWN_POSITIONS: ReadonlyArray<readonly [number, number, number]> = [
  [26, 1.2, 16],
  [-26, 1.2, 16],
  [26, 1.2, -16],
  [-26, 1.2, -16],
]

export const BOT_PATROL_WAYPOINTS: ReadonlyArray<readonly [number, number, number]> = [
  [22, 0, 18],
  [-22, 0, 18],
  [22, 0, -18],
  [-22, 0, -18],
  [0, 0, 0],
  [14, 0, 6],
  [-14, 0, -6],
  [10, 0, -12],
  [-12, 0, 12],
]

export const THIRD_PERSON = false

export const COLORS = {
  floor: '#2c3d52',
  wall: '#3a4a5e',
  crate: '#4c5b72',
  ramp: '#46566f',
  accent: '#7dd3fc',
  enemy: '#e05252',
  bouncePad: '#31d0aa',
  teleporter: '#8b7cf6',
  pickupHealth: '#43d17c',
  pickupAmmo: '#e0b545',
} as const

export type Difficulty = 'easy' | 'normal' | 'hard'

export interface DifficultyConfig {
  label: string
  description: string
  botHealth: number
  botDamage: number
  botSpeed: number
  detectionRange: number
  shootRange: number
  fireRate: number
  respawnTime: number
  scoreMultiplier: number
}

export const DIFFICULTY: Record<Difficulty, DifficultyConfig> = {
  easy: {
    label: 'Easy',
    description: 'Slower, weaker bots. Get your bearings.',
    botHealth: 60,
    botDamage: 0.6,
    botSpeed: 0.8,
    detectionRange: 24,
    shootRange: 15,
    fireRate: 0.7,
    respawnTime: 5,
    scoreMultiplier: 0.75,
  },
  normal: {
    label: 'Normal',
    description: 'A fair fight. Sweat a little.',
    botHealth: 100,
    botDamage: 1,
    botSpeed: 1,
    detectionRange: 34,
    shootRange: 21,
    fireRate: 1,
    respawnTime: 3.5,
    scoreMultiplier: 1,
  },
  hard: {
    label: 'Hard',
    description: 'Fast, tanky, accurate. Good luck.',
    botHealth: 150,
    botDamage: 1.6,
    botSpeed: 1.2,
    detectionRange: 44,
    shootRange: 26,
    fireRate: 1.5,
    respawnTime: 2.5,
    scoreMultiplier: 1.5,
  },
}