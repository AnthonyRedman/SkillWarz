import type * as RAPIER from '@dimforge/rapier3d-compat'
import type { Difficulty } from './constants'
import { DIFFICULTY } from './constants'
import { BOT_EYE, updateBotBrain, type BotBrain } from './botAI'

const GROUND_RAY = 1
const GROUND_TOLERANCE = 0.05
const BOT_TARGET_LIFT = 0.2

export interface BotVec3 {
  x: number
  y: number
  z: number
}

export interface BotStepResult {
  vx: number
  vy: number
  vz: number
  wantShoot: boolean
}

function isGrounded(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  body: RAPIER.RigidBody,
  pos: BotVec3,
): boolean {
  const ray = new RAPIER.Ray(
    { x: pos.x, y: pos.y, z: pos.z },
    { x: 0, y: -1, z: 0 },
  )
  const hit = world.castRay(
    ray,
    GROUND_RAY,
    false,
    undefined,
    undefined,
    undefined,
    body,
    undefined,
  )
  return hit !== null && hit.timeOfImpact <= 0.9 + GROUND_TOLERANCE
}

function hasLOS(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  from: BotVec3,
  target: BotVec3,
  selfBody: RAPIER.RigidBody,
  targetBody: RAPIER.RigidBody,
): boolean {
  const eye = { x: from.x, y: from.y + BOT_EYE, z: from.z }
  const tx = target.x - eye.x
  const ty = target.y + BOT_TARGET_LIFT - eye.y
  const tz = target.z - eye.z
  const range = Math.hypot(tx, ty, tz)
  if (range < 0.001) return true
  const ray = new RAPIER.Ray(
    { x: eye.x, y: eye.y, z: eye.z },
    { x: tx / range, y: ty / range, z: tz / range },
  )
  const selfHandle = selfBody.handle
  const targetHandle = targetBody.handle
  const hit = world.castRay(
    ray,
    range,
    true,
    undefined,
    undefined,
    undefined,
    selfBody,
    (c) => c.parent()?.handle !== targetHandle && c.handle !== selfHandle,
  )
  return hit === null
}

export function stepBot(
  world: RAPIER.World,
  RAPIER: typeof import('@dimforge/rapier3d-compat'),
  brain: BotBrain,
  body: RAPIER.RigidBody,
  target: BotVec3 | null,
  targetBody: RAPIER.RigidBody | null,
  difficulty: Difficulty,
  dt: number,
): BotStepResult {
  const pos = body.translation()
  const dx = (target?.x ?? pos.x) - pos.x
  const dz = (target?.z ?? pos.z) - pos.z
  const dist = Math.hypot(dx, dz)
  const grounded = isGrounded(world, RAPIER, body, pos)
  const cfg = DIFFICULTY[difficulty]
  const los =
    target !== null &&
    targetBody !== null &&
    dist < cfg.detectionRange &&
    hasLOS(world, RAPIER, pos, target, body, targetBody)
  const vel = body.linvel()

  return updateBotBrain(brain, {
    dt,
    posX: pos.x,
    posY: pos.y,
    posZ: pos.z,
    playerX: target?.x ?? pos.x,
    playerZ: target?.z ?? pos.z,
    hVel: Math.hypot(vel.x, vel.z),
    velY: vel.y,
    dist: target ? dist : 1e9,
    grounded,
    hasLOS: los,
    difficulty,
  })
}