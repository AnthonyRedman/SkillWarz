import { BOT_SPAWN_POSITIONS } from './constants'

export const HUMAN_SPAWNS: ReadonlyArray<readonly [number, number, number]> = [
  [0, 1.2, 19],
  [0, 1.2, -19],
  [30, 1.2, 0],
  [-30, 1.2, 0],
]

export const BOT_SPAWNS: ReadonlyArray<readonly [number, number, number]> =
  BOT_SPAWN_POSITIONS

interface Occupant {
  x: number
  z: number
}

function isClear(
  spawn: readonly [number, number, number],
  occupants: readonly Occupant[],
  minDist: number,
): boolean {
  return occupants.every((o) => {
    const dx = spawn[0] - o.x
    const dz = spawn[2] - o.z
    return dx * dx + dz * dz >= minDist * minDist
  })
}

export function pickSpawn(
  candidates: ReadonlyArray<readonly [number, number, number]>,
  occupants: readonly Occupant[],
  minDist = 3,
): readonly [number, number, number] {
  const shuffled = [...candidates].sort(() => Math.random() - 0.5)
  for (const spawn of shuffled) {
    if (isClear(spawn, occupants, minDist)) return spawn
  }
  for (const spawn of shuffled) {
    if (isClear(spawn, occupants, 1.5)) return spawn
  }
  return shuffled[0]
}