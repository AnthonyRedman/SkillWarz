import { BOT, BOT_PATROL_WAYPOINTS, DIFFICULTY, type Difficulty } from './constants'
import { BOT_WEAPON } from './weapons'

export type BotBrainState = 'patrol' | 'chase' | 'shoot'

export interface BotBrain {
  state: BotBrainState
  wasDead: boolean
  patrolIndex: number
  fireCooldown: number
  strafeSign: number
  stuckTime: number
  wantShoot: boolean
}

export const BOT_EYE = 0.75

const STUCK_TIME = 0.5
const HALF_WAYPOINT = 2
const JUMP_FLOOR_Y = 0.4

export function createBotBrain(seed: number): BotBrain {
  return {
    state: 'patrol',
    wasDead: false,
    patrolIndex: (seed * 7 + 3) % BOT_PATROL_WAYPOINTS.length,
    fireCooldown: 0.6,
    strafeSign: 1,
    stuckTime: 0,
    wantShoot: false,
  }
}

export interface BotBrainUpdate {
  dt: number
  posX: number
  posY: number
  posZ: number
  playerX: number
  playerZ: number
  hVel: number
  velY: number
  dist: number
  grounded: boolean
  hasLOS: boolean
  difficulty: Difficulty
}

export interface BotBrainResult {
  vx: number
  vy: number
  vz: number
  wantShoot: boolean
}

export function updateBotBrain(brain: BotBrain, u: BotBrainUpdate): BotBrainResult {
  const cfg = DIFFICULTY[u.difficulty]
  const detectionRange = cfg.detectionRange
  const shootRange = cfg.shootRange
  const patrolSpeed = BOT.patrolSpeed * cfg.botSpeed
  const chaseSpeed = BOT.chaseSpeed * cfg.botSpeed
  const strafeSpeed = BOT.strafeSpeed * cfg.botSpeed

  const dx = u.playerX - u.posX
  const dz = u.playerZ - u.posZ

  const state = brain.state
  if (state === 'patrol' && u.dist < detectionRange && u.hasLOS) {
    brain.state = 'chase'
  } else if (state === 'chase') {
    if (u.dist < shootRange && u.dist > BOT.minShootRange && u.hasLOS) {
      brain.state = 'shoot'
    } else if (u.dist > detectionRange * 1.3 || !u.hasLOS) {
      brain.state = 'patrol'
    }
  } else if (state === 'shoot') {
    if (u.dist > shootRange || u.dist < BOT.minShootRange || !u.hasLOS) {
      brain.state = 'chase'
    }
  }

  let speed = 0
  let moveX = 0
  let moveZ = 0
  if (brain.state === 'patrol') {
    const wp = BOT_PATROL_WAYPOINTS[brain.patrolIndex]
    const wx = wp[0] - u.posX
    const wz = wp[2] - u.posZ
    if (Math.hypot(wx, wz) < HALF_WAYPOINT) {
      brain.patrolIndex = (brain.patrolIndex + 1) % BOT_PATROL_WAYPOINTS.length
    }
    speed = patrolSpeed
    moveX = wx
    moveZ = wz
  } else if (brain.state === 'chase') {
    speed = chaseSpeed
    moveX = dx
    moveZ = dz
  } else if (brain.state === 'shoot') {
    speed = strafeSpeed
    moveX = -dz * brain.strafeSign
    moveZ = dx * brain.strafeSign
    if (Math.random() < 0.01) brain.strafeSign *= -1
  }
  const lenSq = moveX * moveX + moveZ * moveZ
  if (lenSq > 0) {
    const len = Math.sqrt(lenSq)
    moveX /= len
    moveZ /= len
  }

  let vy = u.velY
  if (speed > 0 && u.hVel < speed * 0.35) {
    brain.stuckTime += u.dt
    if (brain.stuckTime > STUCK_TIME) {
      if (u.grounded) vy = BOT.jumpVelocity
      brain.patrolIndex =
        (brain.patrolIndex + 1 + Math.floor(Math.random() * 2)) % BOT_PATROL_WAYPOINTS.length
      brain.stuckTime = 0
    }
  } else {
    brain.stuckTime = 0
  }
  if (u.posY < JUMP_FLOOR_Y) {
    vy = BOT.jumpUp
  }

  brain.wantShoot = false
  brain.wantShoot = false
  if (brain.state === 'shoot') {
    brain.fireCooldown -= u.dt
    if (brain.fireCooldown <= 0) {
      brain.fireCooldown = 1 / (BOT_WEAPON.fireRate * cfg.fireRate)
      brain.wantShoot = true
    }
  }

  return { vx: moveX * speed, vy, vz: moveZ * speed, wantShoot: brain.wantShoot }
}