# SkillWarz — Prototype → Full Game Plan

**Goal:** Convert the single-player React Three Fiber prototype (`skillwarz-clone/`) into a browser-based multiplayer FPS that matches the feature set and feel of the real **SkillWarz** on CrazyGames: *"fast-paced first-person shooter offering advanced movement mechanics and diverse game modes like Deathmatch, Gun Game, and Skull Hunt… bounce pads, teleports, battle pickups… unlock unique classes, customize your gear, and challenge others or practice against bots."*

**Reference:** [https://www.crazygames.com/game/skillwarz](https://www.crazygames.com/game/skillwarz) — controls: WASD move, Space jump, C crouch/slide, Shift sprint, R reload, LMB fire, RMB aim-down-sight, mouse wheel switch weapon, Q melee, G/F grenades, 1/2/3 select weapons, 4 pickup bonus, Tab scoreboard, ~ menu, T/Y/U chat. Platforms: browser (desktop + mobile/tablet, landscape), plus CrazyGames App.

---

## 1. Where We Are Today (Prototype)

Stack: Vite + React 19 + TypeScript + `@react-three/fiber` + `@react-three/rapier` (Rapier physics) + `@react-three/drei` (keyboard controls) + Zustand (single-player game state). Already implemented:

- **Movement:** WASD walk/sprint, jump, air control, slide (Shift+C), head bob, eye-height camera, footstep audio. `Player.tsx`, `PlayerCamera.tsx`, `PlayerControls.tsx`.
- **Combat:** Hitscan via Rapier `castRay`; pistol / rifle / shotgun with per-weapon damage, fire rate, spread, pellets, recoil, reload, ammo. `Weapons/`, `projectiles.ts`, `combat.ts`.
- **Enemies:** 4 bots with patrol/chase/strafe/shoot AI, respawn, hitmarkers, difficulty tiers (Easy/Normal/Hard). `Enemies/Bot.tsx`, `Enemies/BotAI.tsx`, `DIFFICULTY` in `constants.ts`.
- **Map:** Arena with walls, crates, ramps, a central platform, bounce pads, teleporters, day/night lighting toggle, health/armor/ammo pickups. `Map/`.
- **Meta/UI:** Start menu → difficulty screen → game; HUD (health/armor/ammo/weapon), kill feed, scoreboard (Tab), damage flash, crosshair, pause. `UI/`, `gameStore.ts`.

**Single-player only.** All state is client-side in `useGame` (Zustand). There is no server, no player identity, no persistence, no matchmaking.

---

## 2. Target Feature Set (from the real game)

| Feature | Real SkillWarz | Current prototype | Effort |
|---|---|---|---|
| Multiplayer (players + bots) | Yes | No | **High** — core work |
| Deathmatch mode | Yes | Implicit (vs bots) | Medium |
| Gun Game mode | Yes | No | Medium |
| Skull Hunt mode | Yes | No | Medium |
| Advanced movement (slide, bounce pads, teleports) | Yes | Slide + pads + teleports | Low (already have) |
| Battle pickups | Yes | Health/armor/ammo | Low |
| Classes (unlockable) | Yes | No | Medium |
| Gear/loadout customization | Yes | No | Medium |
| Aim down sight (RMB) | Yes | No | Low |
| Melee (Q) | Yes | No | Low |
| Grenades (G / F) | Yes | No | Low |
| Pickup-bonus hotkey (4) | Yes | No | Medium |
| Day/night dynamic maps | Yes | Day/night toggle | Low |
| Multiple maps | Yes | 1 arena | Medium |
| Lobby + match flow | Yes | Menu → play | Medium |
| Scoreboard with all players | Yes | Tab (local) | Medium |
| Chat (T/Y/U) | Yes | No | Low |
| Spray | Yes | No | Low |
| Mobile/tablet support | Yes (landscape + app) | No | High |
| Persistence (account/progression) | Yes | No | High |

---

## 3. High-Level Architecture

### 3.1 Authoritative server model
The prototype's `useGame` store, AI, and physics all run locally. For a real multiplayer game we must move to **authoritative server + thin client**:

```
Client (browser)                    Server (Node)
─────────────────                   ─────────────
R3F canvas (render only)   ─────▶   Colyseus room
Input state (keys/mouse)   👈───▶   Input buffer → tick loop
Interpolation + prediction  ◀────   Physics state (Rapier headless)
HUD/UI from state deltas            Game logic (modes, pickups, scores)
```

- **Server:** Node.js + **Colyseus**(WebSocket rooms) + **@dimforge/rapier3d-compat** in headless mode (no rendering) running the same physics sim as the client. The server is the *only* place physics and damage resolve.
- **Clients** send a compact **input snapshot** each frame (movement dir, jump/sprint/crouch/slide, weapon, aim/grenade/melee events) and receive **state snapshots** (positions, health, scores) at ~20–30 Hz.
- **Client prediction:** locally integrate player movement against the last confirmed server state; reconcile on snapshot (Rapier makes this deterministic-ish; use fixed timestep on both sides).
- **Anti-cheat (basic):** server re-simulates, validates rate/speed, flags impossible input. Keep it pragmatic for v1.

### 3.2 Code sharing (shared package)
Move game logic into a **shared module** imported by both server and client so rules can't diverge:
- `shared/constants.ts` — world, movement, weapons (extend current `constants.ts` / `weapons.ts`).
- `shared/input.ts` — input snapshot schema.
- `shared/state.ts` — player/mode state types + a serialization schema.
- Keep R3F/three-only stuff (models, camera, lighting) on the client only.

### 3.3 Refactor `gameStore.ts` out of single-player mode
Rewrite `useGame` into a thin subscription layer fed by server snapshots. Local AI (`BotAI.tsx`) is deleted; bots become *server-controlled players* streamed like any other player (same netcode path — big win: players and bots share code).

---

## 4. Workstreams & Milestones

### Phase 0 — Refactor foundation (no visible change)
1. Extract all tuning values (`constants.ts`, `weapons.ts`) into `shared/`; client imports from there.
2. Introduce an `EntityStore` (players keyed by id) to replace singleton bot/player state — reuses pattern in `gameStore.ts`.
3. Freeze the fixed-timestep (`1/60`) physics update into a step function callable by both server ticks and client prediction.
4. Add TypeScript project references / a `packages/shared` workspace (or simple `shared/` folder + tsconfig paths).
5. Port bots to pure state machines (already mostly data-driven in `BotAI.tsx`) so they run headless on the server.

### Phase 1 — Multiplayer integration
1. **Colyseus room** `deathmatch`: `onJoin` creates `PlayerState`; `onMessage('input', …)` writes to the input buffer; `onUpdate` steps sim and broadcasts snapshots.
2. **Netcode on client:** `useNet` hook (connect, room, snapshot subscription) replacing direct `useGame` reads for positions/health.
3. **Client prediction + reconciliation:** local capsule for the camera-driven player; replay/lerp for remote players (`Mesh` at interpolated positions).
4. **Spawn system:** resolve spawn points, randomize, avoid spawning on top of an enemy.
5. **Death/respawn/score pipeline** moved server-side; client just renders event feed.
6. Bare-bones public matchmaking: join-first-room fallback, then a lobby list.

### Phase 2 — Game modes
Mode selection happens on the server (authoritative); only render differs on client.

1. **Deathmatch (existing gameplay):** Free-for-all, first to N kills or T minutes. Scoreboard already exists — add remote players.
2. **Gun Game:** On kill, weapon upgrade in a fixed ladder (pistol → rifle → shotgun → …, final: knife). Server tracks ladder per player.
3. **Skull Hunt:** Moving skull pickup; carrying it shows your position to everyone (automatic "wall-hack"); killing the carrier awards points + score streak; the carrier gets speed boost. Reuses `Pickups.tsx` respawn logic.
4. **Mode templates:** each mode = config (win condition, scoring, pickup rules) + server logic; add new modes by adding a config, not new netcode.

### Phase 3 — Combat completeness
1. **Aim-down-sight:** RMB → FOV lerp down (e.g. 70→45), tighter spread, slightly slower walk. `PlayerCamera.tsx` + weapon spread multiplier.
2. **Melee (Q):** short-range arc cast; can one-shot in Gun Game finale; simple first-person arm animation.
3. **Grenades (G / F):** physics projectile (Rapier), fuse timer, radius damage + screen shake + audio. Two slots configurable.
4. **Pickup bonus (4):** random buff from a pool (speed, fire rate, health, shield) held on a timer; export existing pickup grant functions server-side.
5. **Spray (T):** static decal on the surface the ray hits; stored per-player maximum count.

### Phase 4 — Classes, gear & persistence
1. **Classes:** config-driven kits (HP/speed/armor mods + starting loadout + passive), e.g. Assault, Scout, Tank. Reuses `DIFFICULTY`-style config records from `constants.ts`.
2. **Loadout customization:** server-persisted profile (weapon selection, class, gear slots/colors).
3. **Unlocks/progression:** XP + leveling; credits from kills for gear; store in a PostgreSQL/Neon instance (already have Neon MCP available) keyed by account.
4. **Auth/accounts:** OAuth (Google/GitHub) via Neon Auth + optional guest ("play as guest") fallback with a local UUID.

### Phase 5 — Match flow, menus, maps, chat
1. **Lobby & match flow:** create/join room → class & loadout select → warm-up → match → post-match scoreboard → MVP.
2. **Chat & command menu (T/Y/U, ~):** room broadcast; `~` opens a settings menu (sensitivity, FOV, binds, quality).
3. **More maps / day-night cycle:** map file format (static boxes + explicit bounce pad/teleporter/pickup spawns from current `Map/` components); **dynamic cycle**: time-of-day lerp, automatic dusk/night with ambient occlusion dimming via `Lighting.tsx`.
4. **2D minimap** (small canvas overlay) — especially needed for Skull Hunt.

### Phase 6 — Mobile & CrazyGames integration
1. **Mobile:** virtual joystick (left thumb) + look/aim drag (right thumb) + context buttons (jump/sprint/crouch/slide/reload/fire/ADS/switch); landscape lock; touch → pointer-lock substitute; test DPR/performance (large arena is the bounding case).
2. **CrazyGames SDK:** init in `main.tsx`, happy/cancel/start buttons for ads, game-start/game-end events, debounce, `sdk.debug.settings` preview. Loaded only on the CrazyGames domain.

---

## 5. Concrete Code Changes (mapping to current files)

| Current file | Action |
|---|---|
| `store/gameStore.ts` | Rewrite: keep UI flags (started/paused/night); replace positional/combat state with server snapshot subscriptions. |
| `Player.tsx` | Split into **local prediction** (input → expected physics) and **render** (apply confirmed state). Keep capsule-based eye camera. |
| `Bot.tsx` / `BotAI.tsx` | Move to `server/`; Bot becomes a headless player entity sharing the same state type as humans. Delete client-side copies. |
| `Map/Walls.tsx`, `BouncePad.tsx`, `Teleporter.tsx`, `Pickups.tsx`, `Lighting.tsx` | Keep client visuals; add **mirror logic in New()/Update() on server** (pads/teleports/pickups are server-authoritative). Factor into `shared/map.ts`. |
| `Weapons/WeaponManager.tsx`, `Bullets.tsx`, `utils/projectiles.ts`, `utils/combat.ts` | Split: server owns damage/hitscan/cooldowns; client owns viewmodel, tracers, FX, HUD ammo (server-confirmed). |
| `utils/controls.ts`, `PlayerControls.tsx` | Output **input snapshots** (schema in `shared/input.ts`), not per-frame booleans. |
| `UI/*` (HUD, Scoreboard, KillFeed, Menu) | Render from snapshots + server events. Scoreboard becomes full player list; kill feed uses player names + weapon icons. |
| `index.css` | Add lobby/menu screens, in-game chat box, mobile touch controls, ADS vignette. |
| `App.tsx` | Remount Canvas per room/map; gate on net connection state; CrazyGames SDK init wrapper. |

---

## 6. Networking / Config Decisions (open questions — recommend defaults)

1. **Transport:** Colyseus (recommended) — battle-tested room lifecycle, matchmaking hooks, binary/JSON serialization, scales from hobby to prod.
2. **Tick rate:** server 30 Hz sim step, snapshot broadcast 20–30 Hz with interpolation on clients; fire-rate/recoil feel can be client-predicted.
3. **State sync strategy:** snapshot deltas (full state on spawn only), client interpolation for remote, immediate local prediction for self.
4. **Hosting:** Node server on a VPS/Railway/Fly (nearest region to players); static client on Netlify (where `skillwarz-site/` already lives) or CrazyGames-hosted bundle.
5. **Persistence:** Neon Postgres (MCP already configured) for accounts, loadouts, XP, MMR.

---

## 7. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Physics determinism across client/server | Same Rapier version + fixed timestep; server authoritative; client prediction is cosmetic for self. |
| Scope creep (multiplayer is huge) | Ship v1 as **Deathmatch only**; then Gun Game, then Skull Hunt. Everything else is additive config. |
| Cheating | Server re-simulation validates movement/speed/fire rate. Accept posture: anti-cheat is O(n) checks, not a fortress. |
| Mobile perf (syncing full 3D arena) | Instanced meshes, capped shadows, DPR clamp, WebGL2; profile before optimizing. |
| Cost of a dedicated server | Colyseus is cheap at a few rooms; scale via serverless room limits / regional instances later. |
| Keeping the existing prototype playable | Rebuild under the new shared modules incrementally; the single-player experience becomes "practice vs bots" (the real game has exactly this). |

---

## 8. Definition of Done (v1.0 "matches the real game's core")

- [ ] Join a **Deathmatch room** online with up to 8 players against bots.
- [ ] Slide, bounce pads, teleports, pickups, day/night all work netcode-authoritatively.
- [ ] ADS, melee, grenades, pickup-bonus hotkey implemented.
- [ ] **Gun Game** and **Skull Hunt** modes selectable from a lobby.
- [ ] Classes + loadout selection with **persisted progression** behind optional login.
- [ ] Lobby flow: create/join, class select, warm-up, post-game scoreboard.
- [ ] Works on **desktop browser** and **mobile/tablet (landscape, touch controls)**.
- [ ] **CrazyGames SDK** integrated: ad lifecycle + game-start/end events, tested in the dev preview.
- [ ] "Practice vs bots" single-player still works (reuses existing difficulty screen + arena).

---

## 9. Recommended Order (if you want me to start now)

1. **Phase 0** — extract `shared/` + fixed timestep refactor (safe, no visual change, ~1 session).
2. **Phase 1 minimal** — one Colyseus Deathmatch room on localhost, 2 browser tabs, latency-intolerant version running. This de-risks the entire project.
3. Then Phase 2 (modes) → Phase 3 (combat completeness) → Phase 4 (classes/persistence) → Phase 5–6 (flow, mobile, CrazyGames SDK).

The single biggest decision is **Colyseus + authoritative Rapier server**, because everything (modes, bots, anti-cheat, persistence) hangs off that. It's my recommendation.

# Step 9 and Step 10 are left